# PRD v5 (1/3): Visão, requisitos e conformidade

**Projeto:** Estacionamento com agendamento e acesso por QR code
**Disciplina:** Sistemas Distribuídos (FURB), prof. Gabriel Castellani de Oliveira
**Grupo:** Luiz C. Martendal, Fabian Formento, Guilherme B. Hansen, Lucas Visconti e Venâncio D. Cassua
**Documentos:** PRD v5 (1/3) este · PRD v5 (2/3) arquitetura e tecnologia · PRD v5 (3/3) execução, testes e status
**Versão:** 5.0. Substitui a versão 4.

---

## 1. Resumo

O usuário agenda uma vaga pelo navegador do celular. O Parking reserva a vaga e cobra antecipadamente, pelo componente de banco simulado que fica dentro do próprio Parking. O Parking Control registra uma pré-autorização do acesso. Se o pagamento for aprovado, o agendamento é confirmado e o QR code fica disponível. Se for recusado, ou não for pago em 90 minutos, a reserva é desfeita e a pré-autorização também. Na catraca, o QR é lido, a entrada é registrada e a frente do carro é fotografada para o comprovante. O Notification avisa o usuário em cada etapa. Uma função Lambda, disparada pelo EventBridge, apaga as fotos antigas.

**Infraestrutura:** tudo roda no MiniStack, que simula a AWS na região sa-east-1. Cada unidade de longa duração é declarada como uma instância EC2 simulada e executa em um contêiner Docker próprio. Essa simulação é uma limitação declarada, não uma execução real de EC2 (seção 5 do PRD v5 2/3).

## 2. Contexto e prazos

| Data | Marco | Situação |
|---|---|---|
| Antes de qualquer código | Registro do tema com o professor | **Pendente.** Rascunho na seção 2.1. |
| 25/11/2026 (qua) | Apresentação e defesa | 7 dias corridos a partir de hoje |
| 02/12/2026 (qua) | Código-fonte no Git público | Repositório `LcMartendal/smart-parking` existe, com commit inicial |

### 2.1 Rascunho do registro (meia página)

**Tema:** Estacionamento com agendamento e acesso por QR code.

**Integrantes:** Luiz C. Martendal, Fabian Formento, Guilherme B. Hansen, Lucas Visconti e Venâncio D. Cassua.

**Linguagem de cada serviço:** Parking (Java 25, Spring Boot 4.1), com o componente de banco simulado; Parking Control (Java 25, Spring Boot 4.1); Notification (TypeScript, Node 22, NestJS 12). A limpeza de fotos é uma função Lambda em Python 3.13, que é serviço de nuvem.

**Provedor de nuvem:** MiniStack, que simula a AWS na região sa-east-1 (Opção B do enunciado). Usamos S3 para as fotos, Secrets Manager para os segredos, Lambda com EventBridge para a limpeza periódica e IAM para as permissões. Cada unidade é uma instância EC2 simulada, executada em contêiner Docker. A mensageria é RabbitMQ, em contêiner próprio.

**Fluxo principal:** o usuário agenda pelo celular. O Parking reserva a vaga e cria a cobrança. O Parking Control registra uma pré-autorização do acesso. A cobrança é feita pelo banco simulado, com latência e recusa configuráveis. Se aprovada, o agendamento é confirmado e o QR code fica disponível. Se recusada, ou sem pagamento em 90 minutos, o Parking desfaz a reserva, e o Parking Control desfaz a pré-autorização. No cancelamento, o reembolso é integral até 30 minutos depois da confirmação e de 50% depois disso. Na catraca, o Parking Control valida o QR, registra a entrada e guarda a foto. O Notification avisa o usuário.

**Onde estão os três elementos obrigatórios:**
- *Transação distribuída com compensação:* a reserva do Parking e a pré-autorização do Parking Control são desfeitas juntas quando a cobrança falha ou o agendamento expira. O cancelamento atravessa os dois serviços.
- *Dependência lenta ou instável:* o banco simulado tem latência e recusa configuráveis por variável de ambiente.
- *Evento com vários interessados:* `agendamento.confirmado` é consumido pelo Parking Control e pelo Notification.

## 3. Objetivos e não-objetivos

**Objetivos**
- Atender a todos os requisitos do enunciado (seção 9).
- Demonstrar R1 a R6 (seção 7) e os cenários F1 a F8.
- Demonstrar a recuperação de falhas (seção 8), separando o que é real do que é simulado.
- Criar toda a infraestrutura com Terraform, apontando para o MiniStack.

**Não-objetivos**
- Execução em AWS real. O código de infraestrutura fica pronto para isso, mas não é testado na AWS.
- Nota fiscal eletrônica. A nota é um comprovante simulado.
- Leitura automática de placa. A entrada é feita só por QR code.
- Aplicativo nativo. A interface é uma página web responsiva.
- Banco real. O banco é simulado.
- Alta disponibilidade real. Cada unidade roda em uma única instância de contêiner.

## 4. Perfis

| Perfil | Quem é | Pode |
|---|---|---|
| USUARIO | Motorista, pelo celular | Agendar, cancelar, gerar QR, ver notas e notificações |
| OPERADOR | Funcionário do estacionamento | Ver agendamentos do dia, consultar entradas, abrir a cancela manualmente |
| ADMIN | Administrador | Tudo do operador, além da limpeza manual e da gestão de usuários |
| Dispositivo | Catraca | Enviar entrada e saída com a chave de dispositivo. Não usa JWT. |
| Sistema | EventBridge e jobs internos | Disparam a limpeza. Não são perfis de usuário. |

## 5. Requisitos funcionais

| ID | Requisito | Unidade | Perfil |
|---|---|---|---|
| RF-01 | Cadastrar usuário e fazer login, recebendo JWT com o perfil | Parking | público |
| RF-02 | Criar agendamento para uma janela de 1 hora. Responde 202 com id e `Location`. | Parking | USUARIO |
| RF-03 | Registrar a cobrança automaticamente, com valor fixo, e criar a pré-autorização do acesso | Parking, Parking Control | sistema |
| RF-04 | Confirmar o agendamento quando a cobrança é aprovada | Parking | sistema |
| RF-05 | Desfazer a reserva e a pré-autorização quando a cobrança é recusada | Parking, Parking Control | sistema |
| RF-06 | Expirar agendamentos sem pagamento no prazo, e desfazer a pré-autorização | Parking, Parking Control | sistema |
| RF-07 | Cancelar agendamento confirmado, com reembolso total ou parcial | Parking, Parking Control | USUARIO |
| RF-08 | Gerar o QR code de um agendamento confirmado | Parking | USUARIO |
| RF-09 | Registrar entrada pela catraca, validando o QR, e gerar a nota com a foto | Parking Control | dispositivo |
| RF-10 | Registrar saída pela catraca, fechando a sessão | Parking Control | dispositivo |
| RF-11 | Permitir abertura manual da cancela, com motivo registrado | Parking Control | OPERADOR, ADMIN |
| RF-12 | Listar as entradas de um dia | Parking Control | OPERADOR, ADMIN |
| RF-13 | Listar as notas e acessar a foto de cada uma | Parking Control | USUARIO (as suas), OPERADOR, ADMIN |
| RF-14 | Limpar notas e fotos anteriores a uma data, manualmente | Parking Control | ADMIN |
| RF-15 | Listar as notificações do usuário | Notification | USUARIO |
| RF-16 | Avisar o usuário em cada evento relevante | Notification | sistema |
| RF-17 | Listar os agendamentos do dia | Parking | OPERADOR, ADMIN |
| RF-18 | Apagar fotos antigas no S3, todo dia, pela Lambda disparada pelo EventBridge | Lambda | sistema |
| RF-19 | Apagar notas, sessões, notificações e registros técnicos antigos, pelos jobs de cada serviço | Parking Control, Notification, Parking | sistema |
| RF-20 | Responder 404 quando a foto de uma nota não existe mais | Parking Control | USUARIO, OPERADOR, ADMIN |

## 6. Regras de negócio

| ID | Regra | Variável de ambiente |
|---|---|---|
| RN-01 | Cada janela de 1 hora tem capacidade fixa de vagas | `VAGAS_POR_JANELA=50` |
| RN-02 | Cobrança antecipada, no momento do agendamento | — |
| RN-03 | Prazo de pagamento de 90 minutos. Depois disso, o agendamento expira. | `PRAZO_PAGAMENTO_MIN=90` |
| RN-04 | Cancelamento até 30 minutos depois da confirmação: reembolso de 100% | `CANCELAMENTO_JANELA_MIN=30` |
| RN-05 | Cancelamento depois desse prazo: reembolso de 50% | `CANCELAMENTO_PERCENTUAL_TARDIO=0.5` |
| RN-06 | Cancelamento só antes do início da janela | — |
| RN-07 | Entrada exige QR válido e agendamento `CONFIRMADO` na projeção, sem sessão aberta para o mesmo agendamento | — |
| RN-08 | Saída exige sessão aberta. Não há nova cobrança. | — |
| RN-09 | Foto e nota ficam guardadas até a limpeza automática ou manual | — |
| RN-10 | Se a foto falhar, a entrada segue e a nota fica pendente de foto | — |
| RN-11 | Abertura manual exige agendamento confirmado e fica registrada com motivo e operador | — |
| RN-12 | Tarifa fixa por agendamento | `TARIFA=10.00` |
| RN-13 | O banco simulado tem latência e taxa de recusa configuráveis | `BANCO_LATENCIA_MIN_MS`, `BANCO_LATENCIA_MAX_MS`, `BANCO_TAXA_FALHA` |
| RN-14 | Cobrança aprovada depois da expiração ou do cancelamento gera estorno integral | — |
| RN-15 | Cada cobrança é enviada ao banco com uma chave de idempotência, o id da cobrança | — |
| RN-16 | Erro transitório é repetido dentro do consumidor. Só payload inválido vai para a DLQ. | — |
| RN-17 | Pré-autorização: o Parking Control cria o acesso como `PENDENTE` quando o agendamento é criado. Ele só vira `CONFIRMADO` com o evento de confirmação. Recusa, expiração ou cancelamento o desfazem (`CANCELADO` ou `EXPIRADO`). | — |
| RN-18 | Retenções: fotos e notas com mais de 90 dias; notificações com mais de 30 dias; registros técnicos (outbox publicada e mensagens processadas) com mais de 7 dias | `RETENCAO_FOTOS_DIAS=90`, `RETENCAO_NOTIFICACOES_DIAS=30`, `RETENCAO_TECNICA_DIAS=7` |
| RN-19 | Ao apagar a foto, a nota permanece até o job do serviço apagá-la. Enquanto isso, a foto responde 404 (RF-20). | — |

## 7. Requisitos de sistemas distribuídos (R1 a R6)

| ID | Requisito do enunciado | Como é atendido | Onde é verificado |
|---|---|---|---|
| R1 | At-least-once com idempotência | Consumidores gravam o `messageId` na mesma transação do efeito. O banco simulado é idempotente pela chave da cobrança (RN-15). | F3 |
| R2 | Concorrência sem venda dupla | Reserva com `UPDATE ... WHERE ocupadas < capacidade`. Cobrança com `SELECT ... FOR UPDATE SKIP LOCKED`. Versão otimista no agendamento. Uma sessão aberta por agendamento. | F5 |
| R3 | API assíncrona com 202 | `POST /api/agendamentos` responde 202 com `Location`. | Integração e F5 |
| R4 | Consumidores concorrentes | Notification com 2 réplicas na mesma fila. Ordenação discutida na apresentação. | F8 |
| R5 | Dependência instável simulada | Banco simulado com latência e recusa por variável de ambiente | F1, F7 |
| R6 | Reconexão ao broker | Consumidores reconectam sozinhos. A outbox reenvia eventos pendentes. O RabbitMQ volta sozinho (RB-05). | F6 |

## 8. Recuperação de falhas

Cada requisito indica se é **real** (executado de verdade no ambiente) ou **simulado** (representado, sem execução real do mecanismo).

| ID | Requisito | Tipo | Como é atendido | Verificação |
|---|---|---|---|---|
| RB-01 | Se um contêiner cai, ele volta sozinho | Real | `restart: unless-stopped` | `docker kill` e volta em menos de 15 s |
| RB-02 | Se um contêiner fica unhealthy sem sair, ele é reiniciado | Real | Contêiner `autoheal` | Processo travado é reiniciado |
| RB-03 | Se o host reinicia, os serviços voltam sozinhos | Simulado | Reinício do daemon Docker, com as mesmas políticas de restart. Um reboot real do host não é executado. | `sudo systemctl restart docker` e verificação dos serviços |
| RB-04 | Se a instância falha, uma nova é criada e a unidade é reimplantada | Simulado | `terraform apply -replace` recria o registro da instância. O script de deploy da unidade sobe o contêiner. | Substituir a instância do Parking e verificar que o serviço volta |
| RB-05 | O broker volta a funcionar sem intervenção | Real | RabbitMQ com restart, healthcheck, volume Docker nomeado, filas quorum e mensagens persistentes | F6 |

**Limite conhecido:** se o volume do broker for apagado, mensagens confirmadas e ainda não consumidas podem se perder. O volume nomeado persiste entre reinícios do contêiner, mas não é protegido contra remoção do volume.

## 9. Conformidade com o enunciado

| Exigência | Como atendemos | Status |
|---|---|---|
| Pelo menos 3 microsserviços, em duas linguagens | Parking (Java), Parking Control (Java), Notification (TypeScript). Autorizado pelo professor, conforme relato do grupo. | Planejado. Falta confirmar por escrito (P-01). |
| Mensageria assíncrona | RabbitMQ em contêiner próprio | Planejado |
| Serviços de nuvem, com mensageria obrigatória | Mensageria: RabbitMQ em contêiner. Armazenamento: S3. Segredos: Secrets Manager. Computação: Lambda e EC2 simulada. Agendamento: EventBridge. Duas categorias gerenciadas, como exige a regra. | Planejado |
| Banco por serviço | Três PostgreSQL, um por serviço | Planejado |
| Contratos explícitos | `contracts/` com JSON Schema e envelope padrão | Planejado. Falta atualizar para seis eventos. |
| Dockerfile e health check em cada serviço | Parking, Parking Control, Notification, gateway. A Lambda é serviço de nuvem e não tem container. | Planejado |
| Sistema sobe com `docker compose up` | Compose único, com perfis por unidade | Planejado |
| Infraestrutura por scripts versionados | Terraform cria as instâncias EC2 simuladas, rede, permissões, S3, Secrets Manager, Lambda e EventBridge | Planejado. Não aplicado. |
| Opção B: simulação com MiniStack, na região sa-east-1 | Toda a infraestrutura roda no MiniStack | Planejado |
| Cenários F1 a F8 | Scripts em `scripts/cenarios/` | Planejado |
| Falha surpresa | Procedimento escrito por unidade | Planejado |

## 10. Decisões

| ID | Decisão | Origem | Status |
|---|---|---|---|
| D-01 | Cobrança antecipada | Grupo | Confirmada |
| D-02 | Entrada só por QR code | Grupo | Confirmada |
| D-03 | Foto da frente do carro | Grupo | Confirmada |
| D-04 | 50 vagas por janela de 1 hora | Grupo | Confirmada |
| D-05 | Cancelamento só antes do início da janela | Técnica | Revisável |
| D-06 | Falha do QR: abertura manual pelo operador | Grupo | Confirmada |
| D-07 | Interface: página web simples | Grupo | Confirmada |
| D-08 | Login com perfis USUARIO, OPERADOR e ADMIN | Grupo | Confirmada |
| D-09 | Infraestrutura com Terraform | Grupo | Confirmada |
| D-10 | Repositório Git criado pelo grupo | Grupo | Confirmada |
| D-11 | Pagamento dentro do Parking, com interface `BancoAdapter` | Grupo, com autorização do professor | Confirmada |
| D-12 | Parking Control em Java 25 | Grupo | Confirmada |
| D-13 | Limpeza: Lambda para as fotos, jobs dos serviços para as linhas | Técnica | Confirmada |
| D-14 | DynamoDB não adotado | Técnica | Confirmada |
| D-15 | Node 22 (`node:22-alpine`) | Técnica | Confirmada |
| D-16 | Compensação entre dois serviços: o agendamento cria a pré-autorização no Parking Control, e o cancelamento a desfaz | Técnica, atende o item 2 | Confirmada |
| D-17 | **Simulação com MiniStack (Opção B).** Toda a infraestrutura roda no MiniStack, sem conta AWS. | Grupo | **Confirmada** |
| D-18 | Cada unidade é declarada como instância EC2 simulada e executa em contêiner próprio. O MiniStack não executa EC2, então essa é uma simulação declarada. | Técnica, com base na limitação do MiniStack | Confirmada, com limitação declarada (P-03) |
| D-19 | A Lambda apaga só as fotos no S3. A limpeza de linhas fica nos jobs dos serviços. | Técnica | Confirmada |
| D-20 | As imagens são construídas localmente pelo Compose. ECR não é usado. | Técnica | Confirmada |
| D-21 | Reinício em camadas: contêiner (real), contêiner travado (real, autoheal), daemon Docker (simulado como reboot) e instância (simulada, com `terraform apply -replace`) | Técnica, atende o pedido do grupo | Confirmada |
| D-22 | EC2 simulada entra na categoria Computação. O enunciado lista ECS e Lambda como exemplos, e EC2 não aparece na tabela. | Técnica | Confirmar com o professor (P-03) |

## 11. Bônus

| Item | Situação |
|---|---|
| Infraestrutura como código (Terraform) | Planejado. Demonstrar com `terraform apply` e `terraform destroy` no MiniStack. |
| CQRS | Projeção no Parking Control, separada da escrita do Parking. Pode ser apresentada como modelo de leitura. |
| Tracing, autoescala, versionamento de eventos | Fora do escopo |

O bônus só vale o que for demonstrado. O total é limitado a 1,0.
