# PRD v5 (3/3): Execução, testes e status

Ver PRD v5 (1/3) para requisitos e PRD v5 (2/3) para arquitetura.

**Data de referência:** 18/11/2026, à noite (horário de Brasília). Defesa em 25/11/2026.

---

## 1. Ambiente

Todo o sistema roda no MiniStack, na máquina do desenvolvedor, com Docker. Não há conta AWS, custo nem acesso externo para a infraestrutura.

- **Compose único** (`docker-compose.yml`) com perfis por unidade. Cada perfil representa uma instância EC2 simulada.
- **Terraform** cria, no MiniStack, os registros das instâncias, as permissões, o bucket, os segredos, a Lambda e a regra do EventBridge.
- **Script de deploy por unidade** (`scripts/deploy-unidade.sh`), que sobe o perfil da unidade. Faz o papel do `user-data` de uma instância real.

## 2. Implantação simulada

### 2.1 Pré-requisitos

1. Docker e o plugin do Compose instalados.
2. Terraform 1.9 instalado.
3. AWS CLI instalado, com as variáveis `AWS_ACCESS_KEY_ID=test`, `AWS_SECRET_ACCESS_KEY=test` e `AWS_DEFAULT_REGION=sa-east-1`.
4. Arquivo `.env` criado a partir do `.env.example`, com as senhas trocadas.

### 2.2 Terraform

**Pasta:** `infra/`

| Arquivo | Recursos (no MiniStack) |
|---|---|
| `providers.tf` | Providers `aws` ~> 5.0, `random` ~> 3.6 e `archive` ~> 2.4. Endpoints apontando para `http://ministack:4566`. |
| `variables.tf` | Endpoint, região, credenciais de teste, senhas dos bancos, retenções |
| `network.tf` | VPC e sub-rede simuladas, grupos de segurança das cinco unidades |
| `instances.tf` | Cinco `aws_instance` (edge, parking, control, notification, rabbitmq), com tags `unidade` e `perfil` |
| `iam.tf` | Papel das instâncias (leitura dos segredos, escrita no bucket) e papel da Lambda |
| `s3.tf` | Bucket `estacionamento-comprovantes` |
| `secrets.tf` | Segredos de JWT, QR, dispositivo e das três senhas de banco. Valores gerados com `random_password`. |
| `lambda.tf` | Função `limpeza-fotos` (`python3.13`), com o zip gerado por `archive_file` |
| `eventbridge.tf` | Regra `limpeza-diaria` com `cron(0 6 * * ? *)` e alvo na Lambda |
| `outputs.tf` | Nomes das instâncias, do bucket e da Lambda |

`terraform apply` cria tudo no MiniStack. Como o MiniStack não executa EC2, o `apply` não sobe contêiner nenhum: isso é feito pelo script de deploy.

### 2.3 Deploy por unidade

`scripts/deploy-unidade.sh <unidade>`:
1. Lê os segredos no MiniStack com o AWS CLI e escreve o `.env` da unidade, com permissão restrita.
2. Constrói as imagens da unidade a partir dos Dockerfiles.
3. Sobe o perfil da unidade com `docker compose --profile <unidade> up -d`.
4. Espera o healthcheck de cada contêiner da unidade ficar saudável.

### 2.4 Recriação de instância (RB-04, simulado)

1. `terraform apply -replace=aws_instance.<unidade>`: recria o registro da instância.
2. `scripts/deploy-unidade.sh <unidade>`: sobe a unidade de novo.
3. Confirmar que o serviço responde.

### 2.5 Encerramento

`docker compose down` para os contêineres. `docker compose down -v` apaga também os volumes. `terraform destroy` remove os registros do MiniStack.

## 3. Compose por perfil

| Serviço | Perfil | Label `ec2` | Restart | Depende de |
|---|---|---|---|---|
| gateway | edge | edge | unless-stopped | parking, control, notification, interface |
| interface | edge | edge | unless-stopped | — |
| autoheal | todos | (por unidade) | unless-stopped | — |
| parking | parking | parking | unless-stopped | parking-db, rabbitmq, ministack |
| parking-db | parking | parking | unless-stopped | — |
| control | control | control | unless-stopped | control-db, rabbitmq, ministack |
| control-db | control | control | unless-stopped | — |
| notification | notification | notification | unless-stopped (2 réplicas) | notification-db, rabbitmq, ministack |
| notification-db | notification | notification | unless-stopped | — |
| rabbitmq | broker | rabbitmq | unless-stopped | — |
| ministack | infra | — | unless-stopped | — |
| infra | infra | — | "no" | ministack |

O serviço `infra` roda o Terraform. A ordem de subida é: `ministack`, depois `infra`, depois o `rabbitmq` e os bancos, depois os serviços.

## 4. Variáveis de ambiente

| Grupo | Variáveis | Padrão |
|---|---|---|
| Região | `AWS_DEFAULT_REGION` | sa-east-1 |
| Endpoint | `AWS_ENDPOINT_URL` | `http://ministack:4566` |
| Credenciais de teste | `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` | `test` |
| Broker | `RABBITMQ_URL`, `RABBITMQ_USER`, `RABBITMQ_PASSWORD` | `.env` |
| Bancos | `PARKING_DB_PASSWORD`, `CONTROL_DB_PASSWORD`, `NOTIFICATION_DB_PASSWORD` | `.env` |
| Segredos | `SECRET_JWT_KEY`, `SECRET_QR_KEY`, `SECRET_DEVICE_KEY` | nomes no Secrets Manager |
| Bucket | `BUCKET_COMPROVANTES` | `estacionamento-comprovantes` |
| Regras | `VAGAS_POR_JANELA`, `JANELA_AGENDAMENTO_MIN`, `PRAZO_PAGAMENTO_MIN`, `CANCELAMENTO_JANELA_MIN`, `CANCELAMENTO_PERCENTUAL_TARDIO`, `TARIFA` | 50, 60, 90, 30, 0.5, 10.00 |
| Banco simulado | `BANCO_LATENCIA_MIN_MS`, `BANCO_LATENCIA_MAX_MS`, `BANCO_TAXA_FALHA` | 200, 1000, 0.05 |
| Retenção | `RETENCAO_FOTOS_DIAS`, `RETENCAO_NOTIFICACOES_DIAS`, `RETENCAO_TECNICA_DIAS` | 90, 30, 7 |
| Usuários iniciais | `ADMIN_EMAIL`, `ADMIN_SENHA`, `OPERADOR_EMAIL`, `OPERADOR_SENHA` | `.env` |

## 5. Cronograma

Hoje é 18/11. A defesa é em 25/11. Restam sete dias para trabalhar, de 18 a 24/11, incluindo hoje. A ausência de conta AWS poupa um dia de preparação em relação à versão 4.

| Dia | Data | Entrega | Critério de pronto |
|---|---|---|---|
| 1 | 18/11 (hoje) | Registro atualizado e enviado. Decisão D-17 registrada. Compose com perfis, MiniStack, Terraform criando bucket e segredos. | `terraform apply` roda no MiniStack, e `docker compose up` sobe a infraestrutura. |
| 2 | 19/11 qui | Parking em Java: `BancoAdapter`, worker de cobrança, saga, `agendamento.criado`, cancelamento. Remover Payment. | Caminho feliz roda com o banco simulado. |
| 3 | 20/11 sex | Parking Control em Java: projeção PENDENTE, compensação, catraca, QR, foto, nota, 404 da foto. | Entrada e saída funcionam. F1 mostra a compensação nos dois bancos. |
| 4 | 21/11 sáb | Notification em NestJS com reconexão e idempotência. Lambda de fotos. Terraform completo. | Notification sobe com duas réplicas. Lambda invocada. |
| 5 | 22/11 dom | Deploy das cinco unidades. Fluxo principal de ponta a ponta. | Agendamento confirmado e entrada registrada, com todas as unidades de pé. |
| 6 | 23/11 seg | RB-01 a RB-05. F1, F3, F4, F6. | Cenários passam, com saída registrada. |
| 7 | 24/11 ter | F2, F5, F7, F8. Ensaio. Slides, diagrama e justificativas. Procedimento de falha surpresa. | Ensaio sem falhas. |
| — | 25/11 qua | **Defesa** | — |
| — | até 02/12 | Git público, README atualizado, limpeza | — |

**Risco alto.** O caminho crítico é o código de três serviços que ainda não existe. A seção 9 traz o plano de corte.

## 6. Plano de testes

### 6.1 Automatizados

| Unidade | Tipo | Ferramenta |
|---|---|---|
| Parking | Unitário (saga, reembolso, janela) e integração (banco, broker) | JUnit 5, Testcontainers |
| Parking Control | Unitário (QR, sessão) e integração (banco, S3, broker) | JUnit 5, Testcontainers |
| Notification | Integração (banco, broker) | node:test |
| Lambda | Invocação com o bucket de teste | Execução manual, com `aws lambda invoke` |
| Contratos | Exemplos válidos e inválidos contra os schemas | jsonschema |

### 6.2 Cenários F1 a F8

| # | Como provocar | Resultado esperado | Como verificar |
|---|---|---|---|
| F1 | `BANCO_TAXA_FALHA=1.0` no perfil do Parking, criar agendamento | Agendamento cancelado. Pré-autorização desfeita. Aviso enviado. | `agendamento` e `agendamento_projetado` com status `CANCELADO`. `janela.ocupadas` volta a zero. |
| F2 | `docker kill` de uma réplica do Notification durante um lote | Mensagem reentregue. Um único aviso por evento. | Contagem em `notificacao` igual ao número de eventos |
| F3 | Publicar a mesma mensagem cinco vezes pela interface do RabbitMQ | Um único efeito | `mensagem_processada` com uma linha por `messageId` |
| F4 | Publicar payload inválido em `notification.acessos` | Três tentativas, depois DLQ. As outras seguem. | Mensagem em `notification.acessos.dlq` |
| F5 | 100 requisições simultâneas, com `VAGAS_POR_JANELA=10` | 10 respostas 202, 90 recusadas, vagas finais zero | Contagem de respostas. `janela.ocupadas` = 10. |
| F6 | Parar o contêiner do RabbitMQ por 30 s, criando agendamentos durante a parada | Eventos na outbox, depois publicados. Serviços reconectam sozinhos. | `outbox` com `publicado_em` nulo, depois zero |
| F7 | `PRAZO_PAGAMENTO_MIN=1` e `BANCO_LATENCIA_MIN_MS=90000` | Agendamento expirado. Pré-autorização desfeita. Cobrança aprovada tarde, estornada. | Status `EXPIRADO`. Cobrança `ESTORNADA`. |
| F8 | `docker compose up -d --scale notification=3`, com carga | Carga dividida. Sem duplicidade. | Logs das três réplicas. Contagem de avisos igual aos eventos. |

### 6.3 Recuperação (RB-01 a RB-05)

| # | Como provocar | Tipo | Resultado esperado |
|---|---|---|---|
| RB-01 | `docker kill` do contêiner do Parking | Real | Volta sozinho em menos de 15 s |
| RB-02 | Processo travado (exemplo: um processo que deixa de responder ao healthcheck) | Real | `autoheal` reinicia o contêiner |
| RB-03 | `sudo systemctl restart docker` | Simulado (reboot) | Os contêineres voltam sozinhos, com as políticas de restart |
| RB-04 | `terraform apply -replace=aws_instance.parking` e `scripts/deploy-unidade.sh parking` | Simulado | Registro recriado. Serviço volta depois do deploy. |
| RB-05 | Parar o RabbitMQ e reiniciar o contêiner | Real | Broker volta, e os consumidores reconectam |

### 6.4 Demonstração de limpeza

1. Criar notas com data antiga no control-db de teste.
2. Invocar a Lambda com `aws lambda invoke`, usando o endpoint do MiniStack.
3. Verificar que as fotos antigas sumiram e que a foto da nota responde 404 (RF-20).
4. Rodar o job do Parking Control e verificar que a nota antiga sumiu.

## 7. Estado atual

| Item | Situação | Evidência | Falta |
|---|---|---|---|
| Contratos | Desatualizados | Ainda com os schemas de pagamento | Remover e criar `AgendamentoCriado` |
| RabbitMQ (`definitions.json`) | Desatualizado | Ainda com as filas de pagamento | Atualizar as filas e os bindings |
| Terraform | Parcial | Sintaxe verificada para bucket e segredos | Instâncias, IAM, Lambda, EventBridge, deploy |
| Compose | Parcial | Payment e payment-db removidos. YAML válido e `restart` aplicado. | Perfis por unidade, Parking Control em Java, notification e interface |
| Parking (Java) | Pagamento interno implementado: `BancoAdapter`, `BancoSimulado`, cobrança com estados, worker e `agendamento.criado` | Sintaxe verificada com `javac`, sem erros de parse. Não compilado com as dependências. Não executado. | Compilar com Maven. Testar contra PostgreSQL, RabbitMQ e MiniStack. |
| Payment (Java) | **Removido** | Pasta, compose, contratos e filas de pagamento apagados | — |
| Parking Control | **Obsoleto em Python** | 16 testes passavam com PostgreSQL e MiniStack | Reescrever em Java. O Python serve de referência. |
| Notification | Só dependências | `npm install` concluído | Todo o código |
| Lambda | Parcial | Criação e invocação verificadas no MiniStack | Código de limpeza de fotos, disparo pelo EventBridge |
| Gateway e interface | Parcial | Rotas do Parking definidas | Interface e rotas dos demais |
| Documentação do repositório | Desatualizada | `docs/plano_de_execucao.md` e o README falam de Payment | Substituir pelos PRDs v5 e atualizar o README |

## 8. Riscos e pendências

| ID | Risco ou pendência | Impacto | Ação |
|---|---|---|---|
| P-01 | Número de microsserviços. O enunciado diz quatro em três linguagens, e o grupo planejou três em duas, com autorização verbal. | Reprovação no requisito mínimo | Pedir ao professor a confirmação por escrito |
| P-03 | EC2 simulado não é EC2 de verdade. E EC2 não aparece na tabela de categorias do enunciado. | Dúvida sobre a conformidade | Pedir ao professor a confirmação de que EC2 simulado pelo MiniStack é aceito |
| P-05 | Prazo de registro do tema | Pode invalidar o trabalho | Enviar o registro atualizado hoje |
| R-01 | Escopo grande para sete dias | Entrega incompleta | Ver seção 9 |
| R-02 | Parking Control em Java, reescrito do zero | Atraso no caminho crítico | Dia 3 dedicado. O desenho do Python serve de referência. |
| R-03 | Lambda no MiniStack com acesso ao S3 não verificado | Limpeza de fotos não funciona | Testar no dia 1 |
| R-04 | EventBridge não verificado no disparo automático | Limpeza não é automática | Testar no dia 1. Se não disparar, demonstrar por invocação e dizer isso. |
| R-05 | Java sem compilação com as dependências | Erros de build | Compilar com Docker no dia 2 |
| R-06 | Tags de imagem não confirmadas | Build falha | Conferir no dia 1 |
| R-07 | MiniStack perde o estado ao reiniciar | Bucket e segredos somem | O `terraform apply` recria. Rodar o `apply` antes de cada demonstração. |
| R-08 | Demonstração depende do ambiente local na defesa | Falha no vivo | Gravar a demonstração completa como alternativa |

## 9. Plano de corte

Se até 23/11 à noite o fluxo principal não estiver rodando de ponta a ponta:

1. Interface reduzida a login, agendamento, QR e notas.
2. Notificação só em log e na lista do usuário.
3. Painel do operador reduzido à abertura manual.
4. Demonstração de limpeza por invocação apenas.
5. F8 com duas réplicas, em vez de três.

**Não cortar:** R1 a R6, a compensação entre dois serviços (F1), o reinício automático (RB-01, RB-02 e RB-05), e pelo menos F1, F3 e F6.

## 10. Próximos passos

1. Enviar ao professor a pergunta sobre o número de microsserviços (P-01) e sobre o EC2 simulado (P-03).
2. Atualizar e enviar o registro do tema (seção 2.1 do PRD v5 1/3) (P-05).
3. Feito: Payment removido, contratos e `definitions.json` atualizados.
4. Feito, sem compilação: Parking com `BancoAdapter`, worker e `agendamento.criado`. Próximo: compilar e testar.
5. Reescrever o Parking Control em Java.
6. Escrever o Notification.
7. Escrever a Lambda de fotos e verificar o S3 e o disparo do EventBridge (R-03 e R-04).
8. Escrever o Terraform e o script de deploy por unidade.
9. Subir as cinco unidades e executar F1 a F8 e RB-01 a RB-05, guardando a saída.
10. Atualizar o README para que qualquer pessoa recrie o ambiente.

## 11. Checklist de entrega

- [ ] Registro do tema atualizado e enviado
- [ ] Respostas do professor sobre P-01 e P-03 registradas por escrito
- [ ] `docker compose up` e `terraform apply` funcionam a partir de um clone limpo
- [ ] Cada unidade declarada como EC2 simulada, com a limitação declarada na apresentação
- [ ] Cada unidade tem Dockerfile e `/health`
- [ ] Reinício real comprovado (RB-01, RB-02, RB-05), e simulado declarado (RB-03, RB-04)
- [ ] `contracts/` com envelope e os seis eventos
- [ ] R1 a R6 demonstrados e apontados no código
- [ ] Compensação entre dois serviços demonstrada no F1, com os dois bancos
- [ ] Cenários F1 a F8 com scripts e saídas registradas
- [ ] Demonstração da limpeza
- [ ] Justificativa de cada serviço de nuvem na apresentação, incluindo EC2 simulado
- [ ] Justificativa do broker na apresentação
- [ ] Diagrama final no README
- [ ] README com o passo a passo para recriar o ambiente
- [ ] Repositório público (02/12)
- [ ] Nenhum segredo no repositório (`git log -p` sem `.env` e sem estado do Terraform)
- [ ] Procedimento de falha surpresa escrito por unidade

## 12. Revisão deste documento

| Achado | Correção |
|---|---|
| Versão anterior dependia de conta AWS, orçamento, ECR e ASG | Removidos. Simulação completa pelo MiniStack. |
| EC2 podia parecer real | Marcado como simulado em todos os documentos (seções 4 e 5 do PRD v5 2/3) |
| Reinício do host e recriação de instância eram apresentados como reais | RB-03 e RB-04 marcados como simulados, com o mecanismo que os representa |
| Lambda com VPC para os bancos | Lambda restrita ao S3 (D-19) |
| Foto apagada com a nota ainda visível | Requisito RF-20, com 404 |
| Contagem de dias inconsistente | Corrigida para sete dias, de 18 a 24/11 |

**Pendências que a revisão não resolve:** as respostas do professor (P-01 e P-03), o envio do registro (P-05), o teste do disparo do EventBridge e do acesso da Lambda ao S3 (R-03 e R-04), e as tags das imagens (R-06).

**Atualização após a implementação do Parking:** a seção 7 e os passos da seção 10 foram atualizados para o estado atual. Continuam pendentes: Parking Control em Java, Notification, Lambda, Terraform, gateway, interface, cenários e README.
