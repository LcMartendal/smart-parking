# PRD v5 (2/3): Arquitetura e tecnologia

Ver PRD v5 (1/3) para requisitos e decisões, e PRD v5 (3/3) para execução e status.

---

## 1. Visão da arquitetura

```mermaid
flowchart LR
  Celular[Navegador do celular] --> EDGE
  Catraca[Catraca] --> EDGE
  subgraph MINISTACK [MiniStack - sa-east-1 - rede do Compose]
    EDGE[edge: gateway nginx e interface :80]
    EDGE --> PK[parking: Parking Java 25 + parking-db]
    EDGE --> PC[control: Parking Control Java 25 + control-db]
    EDGE --> NT[notification: Notification TS x2 + notification-db]
    PK <--> MQ[rabbitmq: RabbitMQ 4 + volume]
    PC <--> MQ
    MQ --> NT
    MQ --> PC
  end
  PC --> S3[(S3 - fotos)]
  PK -. segredos .-> SM[(Secrets Manager)]
  PC -. segredos .-> SM
  NT -. segredos .-> SM
  EB[EventBridge] --> LB[Lambda limpeza - Python 3.13]
  LB --> S3
```

**Regra de comunicação:** serviços não chamam uns aos outros por HTTP. Toda comunicação entre serviços passa pelo RabbitMQ. O gateway é o único ponto de entrada da aplicação.

## 2. Unidades de execução

| Unidade | Linguagem e framework | Responsabilidade | Banco | Publica | Consome |
|---|---|---|---|---|---|
| **Parking** | Java 25, Spring Boot 4.1 | Login, agendamento, cobrança (banco simulado), saga, cancelamento, expiração, QR | parking-db | `agendamento.criado`, `agendamento.confirmado`, `agendamento.cancelado`, `agendamento.expirado` | nenhuma fila |
| **Parking Control** | Java 25, Spring Boot 4.1 | Pré-autorização, catraca, validação de QR, sessões, foto, nota, consultas, abertura manual | control-db | `acesso.entrada-registrada`, `acesso.saida-registrada` | `control.agendamentos` |
| **Notification** | TypeScript, NestJS 12, Node 22 | Avisos e lista de notificações | notification-db | nenhum | `notification.agendamentos`, `notification.acessos` |
| **Gateway e interface** | nginx | Ponto de entrada, rotas restritas, páginas do usuário | — | — | — |
| **Limpeza de fotos** | Python 3.13, Lambda no MiniStack | Apaga fotos antigas no S3 | — | — | gatilho do EventBridge |

Cada serviço expõe `GET /health`. A Lambda não tem container e é verificada por invocação.

**`BancoSimulado`:** não é um serviço. É uma implementação de `BancoAdapter`, dentro do Parking. Guarda cada chamada na tabela `transacao_banco`, pela chave de idempotência.

## 3. Topologia

Cada unidade é declarada no Terraform como uma instância EC2 simulada. Essa declaração cria o registro no MiniStack, e o contêiner da unidade é executado pelo Compose, com o perfil da unidade.

| Unidade | Instância EC2 simulada | Contêineres | Perfil do Compose | Porta interna |
|---|---|---|---|---|
| edge | `ec2-edge` | gateway (nginx), interface, autoheal | `edge` | 80 publicada |
| parking | `ec2-parking` | parking, parking-db, autoheal | `parking` | 8000, só na rede do Compose |
| control | `ec2-control` | parking-control, control-db, autoheal | `control` | 8000, só na rede do Compose |
| notification | `ec2-notification` | notification (2 réplicas), notification-db, autoheal | `notification` | 8000, só na rede do Compose |
| rabbitmq | `ec2-rabbitmq` | rabbitmq, autoheal | `broker` | 5672 e 15672 publicadas para o administrador |

Cada contêiner tem a label `ec2=<nome>`, para mostrar qual instância simulada ele representa.

## 4. Serviços de nuvem e justificativas

Região: sa-east-1, no MiniStack.

| Categoria | Serviço | Uso | Por que este | Verificado no MiniStack |
|---|---|---|---|---|
| Mensageria | RabbitMQ 4, em contêiner | Eventos de agendamento e de acesso | Roteamento por tópico, filas quorum, DLX, confirmação de publicação. Permite demonstrar F4 e F6. | Não se aplica (contêiner) |
| Armazenamento de objetos | S3 | Fotos das entradas | Dados binários fora do banco | Sim (API) |
| Segredos | Secrets Manager | Chaves de JWT, QR e dispositivo, e senhas dos bancos | Segredos fora do código e do repositório | Sim (API) |
| Computação | EC2 simulada | Uma instância por unidade | Exigência do grupo. A instância é um registro no MiniStack, e o contêiner é a execução. | Só como metadado (seção 5) |
| Computação | Lambda | Limpeza de fotos antigas | Execução sob demanda, sem servidor para manter | Criação e invocação verificadas |
| Agendamento | EventBridge (regra cron) | Dispara a Lambda diariamente | Gatilho gerenciado | Regra criada e listada. Disparo automático não verificado. |
| Permissões | IAM | Papéis das instâncias e da Lambda | Permissões declaradas, com menor privilégio | Criação de papel verificada |

**Não usados:** ECR (as imagens são construídas localmente) e AWS Budgets (não há custo na simulação).

Pela regra do enunciado, há mensageria (RabbitMQ) e duas categorias gerenciadas (S3 e Secrets Manager). Computação é cumprida pela Lambda e pela EC2 simulada.

## 5. O que é real e o que é simulado

| Item | Real ou simulado | Explicação |
|---|---|---|
| Contêineres, portas, redes, health checks | Real | Executados pelo Docker |
| Reinício de contêiner e de contêiner travado | Real | `restart` e `autoheal` |
| Reinício do daemon Docker | Real, mas representa um reboot | Não é o reboot de uma máquina |
| Broker e reconexão dos consumidores | Real | Executados pelo Docker |
| S3, Secrets Manager, IAM | Real na API do MiniStack | O MiniStack guarda o estado e responde como a AWS |
| Lambda | Real na execução | Criação e invocação verificadas |
| EventBridge | Regra real, disparo não verificado | Precisa de teste |
| **EC2** | **Simulado** | O MiniStack cria a instância como metadado. O `user-data` não é executado, e não há máquina virtual. |
| **Recriação de instância (RB-04)** | **Simulado** | `terraform apply -replace` recria o registro, e o script de deploy sobe a unidade |
| **Rede entre instâncias** | **Simulado** | A rede é a do Compose. As instâncias não têm rede própria. |

## 6. Mensageria

**Broker:** RabbitMQ 4.x, `rabbitmq:4-management`.

**Justificativa para a apresentação:** roteamento por tópico (`agendamento.*`, `acesso.*`), filas quorum com limite de tentativas e dead-letter exchange, e confirmação de publicação. Permite demonstrar F4 e F6 de forma direta.

**Topologia** (carregada de `rabbitmq/definitions.json` na inicialização):

| Elemento | Nome | Tipo | Consumidor |
|---|---|---|---|
| Exchange | `estacionamento` | topic | — |
| Exchange de DLQ | `estacionamento.dlx` | direct | — |
| Fila | `control.agendamentos` | quorum | Parking Control (`agendamento.*`) |
| Fila | `notification.agendamentos` | quorum | Notification (`agendamento.*`) |
| Fila | `notification.acessos` | quorum | Notification (`acesso.*`) |
| Filas de DLQ | `<fila>.dlq` para cada fila acima | quorum | — |

O evento `agendamento.*` tem dois interessados: Parking Control e Notification.

Limite de tentativas: `x-delivery-limit=3`. Erro transitório não conta: é repetido dentro do consumidor (RN-16).

**Publicação:** outbox. O evento é gravado na mesma transação da mudança de estado e publicado depois, com confirmação do broker.

## 7. Contratos

**Pasta:** `contracts/`
- `envelope.schema.json`: envelope padrão.
- `eventos/<Tipo>.v1.schema.json`: um schema por evento.

**Envelope:** `messageId`, `correlationId`, `type`, `version`, `occurredAt`, `payload`.

**Eventos v1 (seis tipos):**

| Tipo | Routing key | Produtor | Payload | Consumidores |
|---|---|---|---|---|
| AgendamentoCriado | `agendamento.criado` | Parking | agendamentoId, usuarioId, inicio, fim, expiraEm | Parking Control |
| AgendamentoConfirmado | `agendamento.confirmado` | Parking | agendamentoId, usuarioId, inicio, fim, confirmadoEm | Parking Control, Notification |
| AgendamentoCancelado | `agendamento.cancelado` | Parking | agendamentoId, usuarioId, motivo, percentualReembolso | Parking Control, Notification |
| AgendamentoExpirado | `agendamento.expirado` | Parking | agendamentoId, usuarioId | Parking Control, Notification |
| EntradaRegistrada | `acesso.entrada-registrada` | Parking Control | sessaoId, agendamentoId, usuarioId, origem, motivo, fotoKey, registradaEm | Notification |
| SaidaRegistrada | `acesso.saida-registrada` | Parking Control | sessaoId, agendamentoId, usuarioId, registradaEm | Notification |

**Removidos:** CobrancaSolicitada, EstornoSolicitado, PagamentoAprovado, PagamentoRecusado e PagamentoEstornado. São internos ao Parking e não passam pelo broker.

**Schema novo:** `AgendamentoCriado.v1.schema.json`.

## 8. Compensação entre dois serviços (item 2)

A operação de agendamento atravessa o Parking e o Parking Control. Quando um passo falha, os dois são desfeitos.

**Sequência com sucesso:**
1. O Parking reserva a vaga e cria o agendamento como `AGUARDANDO_PAGAMENTO`. Na mesma transação, grava `agendamento.criado` na outbox.
2. O Parking Control consome `agendamento.criado` e cria a projeção `PENDENTE`. A entrada não é liberada nesse estado.
3. O banco simulado aprova a cobrança. O Parking confirma o agendamento e publica `agendamento.confirmado`.
4. O Parking Control muda a projeção para `CONFIRMADO`. O Notification avisa o usuário.

**Sequência com falha (F1):**
1. O banco recusa a cobrança. O Parking libera a vaga, marca o agendamento como `CANCELADO` e publica `agendamento.cancelado`.
2. O Parking Control consome o cancelamento e muda a projeção `PENDENTE` para `CANCELADO`. Essa é a compensação no segundo serviço.
3. O Notification avisa o usuário.

**Expiração:** o job do Parking expira o agendamento sem pagamento no prazo, publica `agendamento.expirado`, e o Parking Control muda a projeção para `EXPIRADO`.

**Cancelamento pelo usuário:** o Parking calcula o reembolso, pede o estorno ao banco simulado e, quando o estorno é confirmado, publica `agendamento.cancelado`. O Parking Control muda a projeção para `CANCELADO`.

**Ordem dos eventos:** `agendamento.criado` é consumido antes de `agendamento.confirmado`, porque os dois saem da mesma outbox e vão para a mesma fila. Se o `confirmado` chegar primeiro (caso raro), o Parking Control cria a projeção direto como `CONFIRMADO`.

**Verificação (F1):** o estado final é conferido nos dois bancos: `agendamento` com status `CANCELADO` no parking-db, e `agendamento_projetado` com status `CANCELADO` no control-db.

## 8.1 Fluxo de agendamento e cobrança (worker)

O banco simulado pode levar até 90 s, então a espera nunca fica dentro de uma transação do banco de dados. O fluxo se divide em três transações separadas.

1. **Criação (RF-02, RF-03):** uma transação reserva a vaga, cria o agendamento como `AGUARDANDO_PAGAMENTO`, cria a cobrança como `PENDENTE` e grava `agendamento.criado` na outbox.
2. **Lote (a cada 1 s):** o worker pega até 20 cobranças com `SELECT ... FOR UPDATE SKIP LOCKED`, marca as cobranças pendentes como `ENVIADA_AO_BANCO` e confirma a transação. O `SKIP LOCKED` impede que dois workers peguem a mesma cobrança (R2).
3. **Banco (fora de transação):** cada cobrança é enviada ao banco em uma thread virtual, com a chave de idempotência igual ao id da cobrança. Os estornos usam uma chave derivada do id da cobrança, para que nunca se confundam com a cobrança.
4. **Resultado (transação própria):** a cobrança aprovada confirma o agendamento e publica `agendamento.confirmado`. A cobrança recusada cancela o agendamento, libera a vaga e publica `agendamento.cancelado` (F1). Se o agendamento já estiver expirado ou cancelado, a aprovação vira estorno integral (F7).
5. **Recuperação:** uma cobrança que fica em `ENVIADA_AO_BANCO` por mais de `RECUPERACAO_COBRANCA_SEGUNDOS` (120 s por padrão, acima da latência máxima do banco simulado) volta ao lote. Como o banco é idempotente pela chave, o reenvio não gera cobrança dupla.

Qualquer falha em uma tarefa é registrada em log e não derruba o worker. A cobrança fica para a próxima tentativa.

## 9. Máquinas de estado

**Agendamento (Parking):**

| De | Para | Gatilho |
|---|---|---|
| — | AGUARDANDO_PAGAMENTO | Criação |
| AGUARDANDO_PAGAMENTO | CONFIRMADO | Cobrança aprovada |
| AGUARDANDO_PAGAMENTO | CANCELADO | Cobrança recusada |
| AGUARDANDO_PAGAMENTO | EXPIRADO | Prazo vencido |
| CONFIRMADO | CANCELAMENTO_SOLICITADO | Pedido de cancelamento com reembolso |
| CONFIRMADO | CANCELADO | Pedido de cancelamento sem reembolso |
| CANCELAMENTO_SOLICITADO | CANCELADO | Estorno concluído |

**Projeção de acesso (Parking Control):**

| De | Para | Gatilho |
|---|---|---|
| — | PENDENTE | `agendamento.criado` |
| PENDENTE | CONFIRMADO | `agendamento.confirmado` |
| PENDENTE | CANCELADO | `agendamento.cancelado` |
| PENDENTE | EXPIRADO | `agendamento.expirado` |
| CONFIRMADO | CANCELADO | `agendamento.cancelado` |
| CONFIRMADO | EXPIRADO | `agendamento.expirado` |

**Cobrança (Parking):**

| De | Para | Gatilho |
|---|---|---|
| — | PENDENTE | Criação |
| PENDENTE | ENVIADA_AO_BANCO | Worker pega a cobrança |
| ENVIADA_AO_BANCO | APROVADA | Banco aprova |
| ENVIADA_AO_BANCO | RECUSADA | Banco recusa |
| APROVADA | ESTORNO_PENDENTE | Cancelamento ou aprovação tardia |
| ESTORNO_PENDENTE | ESTORNADA | Banco confirma o estorno |

Todas as transições são condicionais (`WHERE status = ...`). Uma transição fora de ordem não tem efeito.

## 10. Dados

| Banco | Tabela | Finalidade |
|---|---|---|
| parking-db | `usuario` | Usuários e perfis |
| parking-db | `janela` | Capacidade por horário, com `check (ocupadas <= capacidade)` |
| parking-db | `agendamento` | Agendamentos, com `versao` para controle otimista |
| parking-db | `cobranca` | Cobranças, com `unique (agendamento_id)` |
| parking-db | `transacao_banco` | Chamadas ao banco simulado, por chave de idempotência |
| parking-db | `outbox` | Eventos a publicar |
| control-db | `agendamento_projetado` | Projeção de acesso: PENDENTE, CONFIRMADO, CANCELADO ou EXPIRADO |
| control-db | `sessao` | Sessões de acesso, com índice único parcial para `status = 'ABERTA'` |
| control-db | `nota` | Comprovantes, com referência à foto |
| control-db | `mensagem_processada`, `outbox` | Idempotência e publicação |
| notification-db | `notificacao` | Avisos do usuário |
| notification-db | `mensagem_processada` | Idempotência |

Migrations: Flyway no Parking e no Parking Control. TypeORM no Notification.

## 11. Entrada, saída, notas e limpeza

**Entrada (RF-09):** a catraca envia `POST /api/catraca/entrada` com o QR, a foto em base64 e a chave de dispositivo. O Parking Control valida a assinatura, a validade e o status `CONFIRMADO` na projeção. Verifica que não há sessão aberta. Grava a foto no S3 em `fotos/{sessaoId}.jpg`, cria a nota e grava `acesso.entrada-registrada` na outbox. Responde `abrir: true`. Se a foto falhar, a entrada segue e a nota fica pendente (RN-10).

**Saída (RF-10):** a catraca envia `POST /api/catraca/saida` com o QR. A sessão fecha e `acesso.saida-registrada` é publicado.

**Abertura manual (RF-11):** o operador envia `POST /api/operador/abertura-manual` com o id do agendamento e o motivo.

**Foto de nota (RF-20):** `GET /api/notas/{id}/foto` lê o objeto no S3. Se o objeto não existe mais, responde 404, e não 500.

**Limpeza:**
- Lambda (RF-18): lista objetos em `fotos/` com data de modificação anterior a `RETENCAO_FOTOS_DIAS` e os apaga. Só usa S3 (D-19).
- Parking Control (RF-19): job diário que apaga notas e sessões fechadas anteriores a `RETENCAO_FOTOS_DIAS`. A foto já foi apagada pela Lambda.
- Notification (RF-19): job diário que apaga notificações anteriores a `RETENCAO_NOTIFICACOES_DIAS`.
- Parking, Parking Control e Notification: job diário que apaga outbox publicada e mensagens processadas anteriores a `RETENCAO_TECNICA_DIAS`.

## 12. Reinício e recuperação

| Camada | O que cai | Quem reinicia | Real ou simulado |
|---|---|---|---|
| Contêiner | Processo termina | Docker (`restart: unless-stopped`) | Real |
| Contêiner travado | Processo vivo, healthcheck falha | `autoheal` | Real |
| Daemon Docker | Serviço do Docker reinicia | Política de restart dos contêineres | Simulado como reboot |
| Instância EC2 simulada | Registro é substituído | `terraform apply -replace` e script de deploy | Simulado |

**Broker (RB-05):** o RabbitMQ roda com as mesmas camadas, além de volume Docker nomeado, filas quorum, mensagens persistentes e publicação com confirmação. Os consumidores reconectam sozinhos (R6).

**Consumidor Java:** o Spring AMQP reconecta sozinho. O erro transitório é repetido dentro do listener, com espera de 0,5 s até 30 s (RN-16).

**Consumidor Notification:** laço de reconexão com amqplib, espera de 2 s, e retentativa dentro do consumidor.

## 13. APIs

| Método | Rota | Unidade | Perfil |
|---|---|---|---|
| POST | `/api/auth/cadastro` | Parking | público |
| POST | `/api/auth/login` | Parking | público |
| POST | `/api/agendamentos` | Parking | USUARIO (202) |
| GET | `/api/agendamentos` | Parking | USUARIO |
| GET | `/api/agendamentos/{id}` | Parking | dono, OPERADOR, ADMIN |
| POST | `/api/agendamentos/{id}/cancelamento` | Parking | USUARIO (202) |
| GET | `/api/agendamentos/{id}/qr` | Parking | USUARIO |
| GET | `/api/operador/agendamentos?dia=` | Parking | OPERADOR, ADMIN |
| POST | `/api/catraca/entrada` | Parking Control | dispositivo |
| POST | `/api/catraca/saida` | Parking Control | dispositivo |
| POST | `/api/operador/abertura-manual` | Parking Control | OPERADOR, ADMIN |
| GET | `/api/acessos?dia=` | Parking Control | OPERADOR, ADMIN |
| GET | `/api/notas` | Parking Control | USUARIO |
| GET | `/api/notas/{id}/foto` | Parking Control | dono, OPERADOR, ADMIN |
| POST | `/api/admin/notas/limpeza?ate=` | Parking Control | ADMIN |
| GET | `/api/notificacoes` | Notification | USUARIO |

**Gateway (porta 80 da unidade edge):**

| Rota | Destino (nome do serviço no Compose) |
|---|---|
| `/api/auth/`, `/api/agendamentos`, `/api/operador/agendamentos`, `/health` | parking |
| `= /api/operador/abertura-manual`, `/api/catraca/`, `/api/acessos`, `/api/notas`, `/api/admin/` | control |
| `/api/notificacoes` | notification |
| `/` | interface |

Qualquer outra rota responde 404. As rotas internas nunca são expostas. O gateway usa os nomes dos serviços na rede do Compose.

## 14. Segurança

| Mecanismo | Uso | Segredo |
|---|---|---|
| JWT HS256 | Login. Emitido pelo Parking. Validado por Parking, Parking Control e Notification. | `estacionamento/jwt-key` |
| QR JWT HS256 | Assinado pelo Parking, validado pelo Parking Control. Claims: `sub`, `usuarioId`, `jti`, `iat`, `exp`. | `estacionamento/qr-key` |
| Chave de dispositivo | Cabeçalho `X-Device-Key` na catraca | `estacionamento/device-key` |
| Senhas dos bancos | No `.env` do Compose. Também no Secrets Manager, para leitura pelos serviços. | `estacionamento/*-db` |
| Permissões | Papéis IAM declarados no Terraform, com acesso só aos segredos do projeto e ao bucket de fotos | — |

Nenhum segredo fica no código ou no repositório. O `.env` e o estado do Terraform estão no `.gitignore`.

## 15. Stack e versões

| Item | Versão | Situação |
|---|---|---|
| Java | 25 (LTS). Imagens `maven:3.9-eclipse-temurin-25` e `eclipse-temurin:25-jre-alpine`. | Não validado |
| Spring Boot | 4.1.0 | Não compilado com as dependências |
| JJWT | 0.12.6 | — |
| AWS SDK Java | 2.28.0 (`s3`, `secretsmanager`), com endpoint do MiniStack | Não validado |
| TypeScript | 5.6 | Dependência instalada |
| Node | 22 (`node:22-alpine`). Testado localmente com 22.23. | Verificado |
| NestJS | 12 | Dependências instaladas. Código não escrito. |
| TypeORM, amqplib | 0.3.x, 0.10.x | Dependências instaladas |
| Python (Lambda) | 3.13, runtime `python3.13` | Criação e invocação verificadas. Usa só boto3, que já vem no runtime. |
| RabbitMQ | 4.x (`rabbitmq:4-management`) | Tag a confirmar |
| PostgreSQL | 17 (`postgres:17-alpine`) | Tag a confirmar |
| autoheal | `willfarrell/autoheal` | Tag a confirmar |
| nginx | `nginx:alpine` | — |
| Terraform | 1.9. Providers `aws` ~> 5.0, `random` ~> 3.6, `archive` ~> 2.4 | Sintaxe verificada em versão anterior |
| MiniStack | `ministackorg/ministack:latest`, testado com 1.5.41 | S3, Secrets Manager, Lambda, EventBridge, ECR, IAM e ECS respondem à API. EC2 é só metadado. |
