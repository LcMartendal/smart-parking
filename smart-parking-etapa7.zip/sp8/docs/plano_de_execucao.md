# Plano de execução

Este documento foi substituído pelo PRD v5, em `docs/prd/`:

1. `docs/prd/PRD-v5-1-visao-e-requisitos.md`
2. `docs/prd/PRD-v5-2-arquitetura-e-tecnologia.md`
3. `docs/prd/PRD-v5-3-execucao-testes-e-status.md`
