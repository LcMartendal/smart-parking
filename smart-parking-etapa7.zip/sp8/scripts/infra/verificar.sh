#!/usr/bin/env bash
# Verifica a infraestrutura do Dia 1: MiniStack, bucket, segredos, broker, filas e bancos.
set -uo pipefail
cd "$(dirname "$0")/../.."
set -a; source .env; set +a

ENDPOINT="http://localhost:4566"
FALHOU=0
ok()    { echo "[OK]    $1"; }
falha() { echo "[FALHA] $1"; FALHOU=1; }

# AWS CLI com path-style, como no Terraform
CONFIG=$(mktemp)
printf '[default]\nregion = %s\ns3 =\n  addressing_style = path\n' "$AWS_DEFAULT_REGION" > "$CONFIG"
export AWS_CONFIG_FILE="$CONFIG" AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY

curl -sf "$ENDPOINT/_ministack/health" >/dev/null && ok "MiniStack respondendo" || falha "MiniStack fora do ar"

aws --endpoint-url "$ENDPOINT" s3api head-bucket --bucket "$BUCKET_COMPROVANTES" >/dev/null 2>&1 \
  && ok "bucket $BUCKET_COMPROVANTES existe" || falha "bucket $BUCKET_COMPROVANTES não encontrado"

SEGREDOS=$(aws --endpoint-url "$ENDPOINT" secretsmanager list-secrets --query 'SecretList[].Name' --output text 2>/dev/null)
for s in estacionamento/jwt-key estacionamento/qr-key estacionamento/device-key \
         estacionamento/parking-db estacionamento/control-db estacionamento/notification-db; do
  echo "$SEGREDOS" | grep -q "$s" && ok "segredo $s" || falha "segredo $s ausente"
done

curl -sf -u "$RABBITMQ_USER:$RABBITMQ_PASSWORD" "http://localhost:15672/api/overview" >/dev/null \
  && ok "RabbitMQ respondendo" || falha "RabbitMQ fora do ar"

for fila in control.agendamentos notification.agendamentos \
            control.agendamentos notification.acessos; do
  curl -sf -u "$RABBITMQ_USER:$RABBITMQ_PASSWORD" "http://localhost:15672/api/queues/%2F/$fila" \
    | grep -q '"quorum"' && ok "fila quorum $fila" || falha "fila $fila ausente ou não é quorum"
done

for banco in parking control notification; do
  docker compose exec -T "$banco-db" pg_isready -U "$banco" -d "$banco" >/dev/null 2>&1 \
    && ok "banco $banco-db" || falha "banco $banco-db indisponível"
done

rm -f "$CONFIG"
if [ "$FALHOU" -eq 0 ]; then echo "Infraestrutura do Dia 1 OK."; else echo "Há falhas acima."; fi
exit "$FALHOU"
