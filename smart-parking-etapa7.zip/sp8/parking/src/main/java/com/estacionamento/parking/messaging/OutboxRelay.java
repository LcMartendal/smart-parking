package com.estacionamento.parking.messaging;

import java.nio.charset.StandardCharsets;
import java.time.Clock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.estacionamento.parking.config.NegocioProperties;
import com.estacionamento.parking.domain.OutboxEvento;
import com.estacionamento.parking.repository.OutboxRepository;

import com.rabbitmq.client.AMQP;

/** Publica os eventos pendentes com publisher confirms. Se o broker cair, tenta de novo depois (F6). */
@Component
public class OutboxRelay {

    private static final Logger log = LoggerFactory.getLogger(OutboxRelay.class);

    private final OutboxRepository outbox;
    private final RabbitTemplate rabbit;
    private final Clock clock;
    private final String exchange;

    public OutboxRelay(OutboxRepository outbox, RabbitTemplate rabbit, Clock clock, NegocioProperties props) {
        this.outbox = outbox;
        this.rabbit = rabbit;
        this.clock = clock;
        this.exchange = props.exchange();
    }

    @Scheduled(fixedDelayString = "${negocio.outbox-intervalo-ms:1000}")
    @Transactional
    public void publicarPendentes() {
        for (OutboxEvento evento : outbox.findTop100ByPublicadoEmIsNullOrderByCriadoEmAsc()) {
            try {
                publicar(evento);
                evento.marcarPublicado(clock.instant());
            } catch (RuntimeException e) {
                log.warn("broker indisponível; eventos pendentes serão reenviados: {}", e.getMessage());
                return;
            }
        }
    }

    private void publicar(OutboxEvento evento) {
        rabbit.execute(canal -> {
            canal.confirmSelect();
            AMQP.BasicProperties props = new AMQP.BasicProperties.Builder()
                    .contentType("application/json")
                    .messageId(evento.getId().toString())
                    .deliveryMode(2)
                    .build();
            canal.basicPublish(exchange, evento.getRoutingKey(), props,
                    evento.getPayload().getBytes(StandardCharsets.UTF_8));
            canal.waitForConfirmsOrDie(5_000);
            return null;
        });
    }
}
