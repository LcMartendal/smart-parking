package com.estacionamento.parking.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ExpiracaoJob {

    private final AgendamentoService service;

    public ExpiracaoJob(AgendamentoService service) {
        this.service = service;
    }

    @Scheduled(fixedDelayString = "${negocio.expiracao-intervalo-ms:5000}")
    public void executar() {
        service.expirarVencidos();
    }
}
