package com.estacionamento.parking.web;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.estacionamento.parking.service.AuthService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    public record Credenciais(@NotBlank @Email String email, @NotBlank @Size(min = 6) String senha) {
    }

    private final AuthService auth;

    public AuthController(AuthService auth) {
        this.auth = auth;
    }

    @PostMapping("/cadastro")
    @ResponseStatus(HttpStatus.CREATED)
    public void cadastro(@Valid @RequestBody Credenciais c) {
        auth.cadastrar(c.email(), c.senha());
    }

    @PostMapping("/login")
    public Map<String, Object> login(@Valid @RequestBody Credenciais c) {
        AuthService.Sessao sessao = auth.login(c.email(), c.senha());
        return Map.of("token", sessao.token(), "role", sessao.role().name());
    }
}
