package com.estacionamento.parking.repository;

import java.time.Instant;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.estacionamento.parking.domain.Janela;

public interface JanelaRepository extends JpaRepository<Janela, Long> {

    /** Cria a janela se ela ainda não existir. Idempotente. */
    @Modifying
    @Query(value = "insert into janela (inicio, ocupadas, capacidade) values (:inicio, 0, :capacidade) "
            + "on conflict (inicio) do nothing", nativeQuery = true)
    int inserirSeAusente(@Param("inicio") Instant inicio, @Param("capacidade") int capacidade);

    /** Reserva uma vaga só se houver. Retorna 0 quando a janela está cheia (F5). */
    @Modifying
    @Query(value = "update janela set ocupadas = ocupadas + 1 where inicio = :inicio and ocupadas < capacidade",
            nativeQuery = true)
    int reservarVaga(@Param("inicio") Instant inicio);

    @Modifying
    @Query(value = "update janela set ocupadas = ocupadas - 1 where inicio = :inicio and ocupadas > 0",
            nativeQuery = true)
    int liberarVaga(@Param("inicio") Instant inicio);
}
