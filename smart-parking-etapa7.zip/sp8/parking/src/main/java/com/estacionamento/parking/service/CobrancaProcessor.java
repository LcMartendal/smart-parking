package com.estacionamento.parking.service;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.estacionamento.parking.domain.Agendamento;
import com.estacionamento.parking.domain.Cobranca;
import com.estacionamento.parking.domain.StatusAgendamento;
import com.estacionamento.parking.domain.StatusCobranca;
import com.estacionamento.parking.messaging.OutboxService;
import com.estacionamento.parking.repository.AgendamentoRepository;
import com.estacionamento.parking.repository.CobrancaRepository;
import com.estacionamento.parking.repository.JanelaRepository;

/** Regras de resultado da cobrança. Cada método roda em sua própria transação. */
@Service
public class CobrancaProcessor {

    public record Tarefa(UUID cobrancaId, UUID chave, BigDecimal valor, boolean estorno) {
    }

    private final CobrancaRepository cobrancas;
    private final AgendamentoRepository agendamentos;
    private final JanelaRepository janelas;
    private final OutboxService outbox;
    private final Clock clock;

    public CobrancaProcessor(CobrancaRepository cobrancas, AgendamentoRepository agendamentos,
                             JanelaRepository janelas, OutboxService outbox, Clock clock) {
        this.cobrancas = cobrancas;
        this.agendamentos = agendamentos;
        this.janelas = janelas;
        this.outbox = outbox;
        this.clock = clock;
    }

    /** Chave de idempotência do estorno, derivada da cobrança. */
    public static UUID chaveEstorno(UUID cobrancaId) {
        return UUID.nameUUIDFromBytes(("estorno:" + cobrancaId).getBytes(StandardCharsets.UTF_8));
    }

    @Transactional
    public List<Tarefa> reservar(Instant limiteRecuperacao) {
        Instant agora = clock.instant();
        List<Tarefa> tarefas = new ArrayList<>();
        for (Cobranca c : cobrancas.reservarParaProcessar(limiteRecuperacao)) {
            if (c.getStatus() == StatusCobranca.ESTORNO_PENDENTE) {
                tarefas.add(new Tarefa(c.getId(), chaveEstorno(c.getId()), c.getValorEstorno(), true));
            } else {
                c.enviarAoBanco(agora);
                tarefas.add(new Tarefa(c.getId(), c.getId(), c.getValor(), false));
            }
        }
        return tarefas;
    }

    @Transactional
    public void concluirCobranca(UUID cobrancaId, boolean aprovada) {
        Cobranca c = cobrancas.findById(cobrancaId).orElseThrow();
        if (c.getStatus() != StatusCobranca.ENVIADA_AO_BANCO) {
            return;
        }
        Agendamento a = agendamentos.findById(c.getAgendamentoId()).orElseThrow();
        Instant agora = clock.instant();
        if (!aprovada) {
            c.recusar(agora);
            if (a.getStatus() == StatusAgendamento.AGUARDANDO_PAGAMENTO) {
                // Compensação (F1): desfaz a reserva. Nada foi cobrado, então não há estorno.
                janelas.liberarVaga(a.getJanelaInicio());
                a.marcarCancelado(BigDecimal.ZERO);
                publicarCancelado(a, "PAGAMENTO_RECUSADO", BigDecimal.ZERO);
            }
            return;
        }
        c.aprovar(agora);
        if (a.getStatus() == StatusAgendamento.AGUARDANDO_PAGAMENTO) {
            a.confirmar(agora);
            outbox.enfileirar("AgendamentoConfirmado", "agendamento.confirmado", a.getId(), Map.of(
                    "agendamentoId", a.getId().toString(),
                    "usuarioId", a.getUsuarioId().toString(),
                    "inicio", a.getInicio().toString(),
                    "fim", a.getFim().toString(),
                    "confirmadoEm", agora.toString()));
        } else {
            // Aprovação chegou depois da expiração ou do cancelamento: estorno integral (F7, RN-14)
            c.solicitarEstorno(c.getValor(), agora);
        }
    }

    @Transactional
    public void concluirEstorno(UUID cobrancaId) {
        Cobranca c = cobrancas.findById(cobrancaId).orElseThrow();
        if (c.getStatus() != StatusCobranca.ESTORNO_PENDENTE) {
            return;
        }
        c.estornar(clock.instant());
        Agendamento a = agendamentos.findById(c.getAgendamentoId()).orElseThrow();
        if (a.getStatus() == StatusAgendamento.CANCELAMENTO_SOLICITADO) {
            janelas.liberarVaga(a.getJanelaInicio());
            a.marcarCancelado(a.getPercentualReembolso());
            publicarCancelado(a, "CANCELAMENTO_PELO_USUARIO", a.getPercentualReembolso());
        }
    }

    private void publicarCancelado(Agendamento a, String motivo, BigDecimal percentual) {
        outbox.enfileirar("AgendamentoCancelado", "agendamento.cancelado", a.getId(), Map.of(
                "agendamentoId", a.getId().toString(),
                "usuarioId", a.getUsuarioId().toString(),
                "motivo", motivo,
                "percentualReembolso", percentual));
    }
}
