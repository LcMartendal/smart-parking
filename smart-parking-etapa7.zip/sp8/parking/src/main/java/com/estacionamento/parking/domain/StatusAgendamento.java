package com.estacionamento.parking.domain;

public enum StatusAgendamento {
    AGUARDANDO_PAGAMENTO, CONFIRMADO, CANCELAMENTO_SOLICITADO, CANCELADO, EXPIRADO
}
