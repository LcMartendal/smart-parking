package com.estacionamento.parking.messaging;

import java.time.Clock;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.estacionamento.parking.domain.OutboxEvento;
import com.estacionamento.parking.repository.OutboxRepository;

import tools.jackson.databind.ObjectMapper;

@Service
public class OutboxService {

    private final OutboxRepository outbox;
    private final ObjectMapper mapper;
    private final Clock clock;

    public OutboxService(OutboxRepository outbox, ObjectMapper mapper, Clock clock) {
        this.outbox = outbox;
        this.mapper = mapper;
        this.clock = clock;
    }

    /** Deve ser chamado dentro da mesma transação da mudança de estado. */
    @Transactional
    public void enfileirar(String tipo, String routingKey, UUID correlationId, Map<String, Object> payload) {
        Instant agora = clock.instant();
        UUID messageId = UUID.randomUUID();
        Map<String, Object> envelope = new LinkedHashMap<>();
        envelope.put("messageId", messageId.toString());
        envelope.put("correlationId", correlationId.toString());
        envelope.put("type", tipo);
        envelope.put("version", 1);
        envelope.put("occurredAt", agora.toString());
        envelope.put("payload", payload);
        outbox.save(new OutboxEvento(messageId, tipo, routingKey, mapper.writeValueAsString(envelope), agora));
    }
}
