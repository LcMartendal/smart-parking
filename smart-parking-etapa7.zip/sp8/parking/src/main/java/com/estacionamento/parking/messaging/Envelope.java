package com.estacionamento.parking.messaging;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/** Envelope padrão de todas as mensagens (contracts/envelope.schema.json). */
public record Envelope(
        UUID messageId,
        UUID correlationId,
        String type,
        int version,
        Instant occurredAt,
        Map<String, Object> payload) {
}
