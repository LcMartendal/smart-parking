package com.estacionamento.parking.domain;

import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Registro de idempotência (R1). Gravado na mesma transação do efeito. */
@Entity
@Table(name = "mensagem_processada")
public class MensagemProcessada {

    @Id
    @Column(name = "message_id")
    private UUID messageId;

    @Column(name = "processado_em", nullable = false)
    private Instant processadoEm;

    protected MensagemProcessada() {
    }

    public MensagemProcessada(UUID messageId, Instant processadoEm) {
        this.messageId = messageId;
        this.processadoEm = processadoEm;
    }
}
