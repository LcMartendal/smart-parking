package com.estacionamento.parking.domain;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Registro de cada chamada ao banco simulado, pela chave de idempotência. */
@Entity
@Table(name = "transacao_banco")
public class TransacaoBanco {

    @Id
    private UUID chave;

    @Column(nullable = false, length = 16)
    private String tipo;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal valor;

    @Column(nullable = false)
    private boolean aprovada;

    @Column(name = "criada_em", nullable = false)
    private Instant criadaEm;

    protected TransacaoBanco() {
    }

    public TransacaoBanco(UUID chave, String tipo, BigDecimal valor, boolean aprovada, Instant criadaEm) {
        this.chave = chave;
        this.tipo = tipo;
        this.valor = valor;
        this.aprovada = aprovada;
        this.criadaEm = criadaEm;
    }

    public boolean isAprovada() {
        return aprovada;
    }
}
