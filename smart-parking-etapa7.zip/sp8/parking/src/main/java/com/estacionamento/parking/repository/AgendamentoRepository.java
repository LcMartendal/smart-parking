package com.estacionamento.parking.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.estacionamento.parking.domain.Agendamento;
import com.estacionamento.parking.domain.StatusAgendamento;

public interface AgendamentoRepository extends JpaRepository<Agendamento, UUID> {

    List<Agendamento> findByUsuarioIdOrderByInicioDesc(UUID usuarioId);

    Optional<Agendamento> findByIdAndUsuarioId(UUID id, UUID usuarioId);

    List<Agendamento> findByInicioBetweenOrderByInicioAsc(Instant de, Instant ate);

    List<Agendamento> findByStatusAndExpiraEmBefore(StatusAgendamento status, Instant limite);
}
