package com.estacionamento.parking.service;

import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.estacionamento.parking.domain.Role;
import com.estacionamento.parking.domain.Usuario;
import com.estacionamento.parking.repository.UsuarioRepository;
import com.estacionamento.parking.security.JwtService;

@Service
public class AuthService {

    public record Sessao(String token, Role role) {
    }

    private final UsuarioRepository usuarios;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    public AuthService(UsuarioRepository usuarios, PasswordEncoder encoder, JwtService jwt) {
        this.usuarios = usuarios;
        this.encoder = encoder;
        this.jwt = jwt;
    }

    @Transactional
    public void cadastrar(String email, String senha) {
        if (usuarios.findByEmail(email).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "e-mail já cadastrado");
        }
        usuarios.save(new Usuario(UUID.randomUUID(), email, encoder.encode(senha), Role.USUARIO));
    }

    @Transactional(readOnly = true)
    public Sessao login(String email, String senha) {
        Usuario u = usuarios.findByEmail(email)
                .filter(x -> encoder.matches(senha, x.getSenhaHash()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "credenciais inválidas"));
        return new Sessao(jwt.emitirToken(u.getId(), u.getRole()), u.getRole());
    }
}
