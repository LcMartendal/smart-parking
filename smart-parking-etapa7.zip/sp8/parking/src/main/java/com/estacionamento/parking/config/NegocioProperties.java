package com.estacionamento.parking.config;

import java.math.BigDecimal;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "negocio")
public record NegocioProperties(
        int vagasPorJanela,
        int janelaAgendamentoMin,
        int prazoPagamentoMin,
        int cancelamentoJanelaMin,
        BigDecimal cancelamentoPercentualTardio,
        BigDecimal tarifa,
        String exchange,
        String adminEmail,
        String adminSenha,
        String operadorEmail,
        String operadorSenha,
        long bancoLatenciaMinMs,
        long bancoLatenciaMaxMs,
        double bancoTaxaFalha,
        long recuperacaoCobrancaSegundos) {
}
