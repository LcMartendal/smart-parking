package com.estacionamento.parking.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.estacionamento.parking.domain.Cobranca;

public interface CobrancaRepository extends JpaRepository<Cobranca, UUID> {

    Optional<Cobranca> findByAgendamentoId(UUID agendamentoId);

    /** Pega um lote de trabalho sem bloquear o que outro worker já pegou (R2). */
    @Query(value = "select * from cobranca where status in ('PENDENTE', 'ESTORNO_PENDENTE') "
            + "or (status = 'ENVIADA_AO_BANCO' and atualizada_em < :limite) "
            + "order by criada_em limit 20 for update skip locked", nativeQuery = true)
    List<Cobranca> reservarParaProcessar(@Param("limite") Instant limite);
}
