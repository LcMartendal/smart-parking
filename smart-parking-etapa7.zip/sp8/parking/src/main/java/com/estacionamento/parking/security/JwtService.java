package com.estacionamento.parking.security;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

import javax.crypto.SecretKey;

import org.springframework.stereotype.Service;

import com.estacionamento.parking.config.ChavesConfig;
import com.estacionamento.parking.domain.Role;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

/** Emite e valida o JWT de login e o JWT do QR code. As chaves vêm do Secrets Manager. */
@Service
public class JwtService {

    private final SecretKey chaveUsuario;
    private final SecretKey chaveQr;
    private final Clock clock;

    public JwtService(ChavesConfig.Chaves chaves, Clock clock) {
        this.chaveUsuario = Keys.hmacShaKeyFor(chaves.jwt().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        this.chaveQr = Keys.hmacShaKeyFor(chaves.qr().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        this.clock = clock;
    }

    public String emitirToken(UUID usuarioId, Role role) {
        Instant agora = clock.instant();
        return Jwts.builder()
                .subject(usuarioId.toString())
                .claim("role", role.name())
                .issuedAt(Date.from(agora))
                .expiration(Date.from(agora.plus(Duration.ofHours(8))))
                .signWith(chaveUsuario)
                .compact();
    }

    public Claims lerToken(String token) {
        return Jwts.parser().verifyWith(chaveUsuario).build().parseSignedClaims(token).getPayload();
    }

    public String emitirQr(UUID agendamentoId, UUID usuarioId, Instant fim) {
        Instant agora = clock.instant();
        return Jwts.builder()
                .subject(agendamentoId.toString())
                .id(UUID.randomUUID().toString())
                .claim("usuarioId", usuarioId.toString())
                .issuedAt(Date.from(agora))
                .expiration(Date.from(fim))
                .signWith(chaveQr)
                .compact();
    }

    public Claims lerQr(String token) {
        return Jwts.parser().verifyWith(chaveQr).build().parseSignedClaims(token).getPayload();
    }
}
