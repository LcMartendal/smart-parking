package com.estacionamento.parking.web;

import java.net.URI;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.estacionamento.parking.domain.Agendamento;
import com.estacionamento.parking.service.AgendamentoService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@RestController
@RequestMapping("/api/agendamentos")
public class AgendamentoController {

    public record NovoAgendamento(@NotNull Instant inicio) {
    }

    private final AgendamentoService service;

    public AgendamentoController(AgendamentoService service) {
        this.service = service;
    }

    /** R3: responde 202 com o id. O cliente consulta o status depois. */
    @PostMapping
    public ResponseEntity<Map<String, Object>> criar(@Valid @RequestBody NovoAgendamento corpo, Authentication auth) {
        Agendamento a = service.criar(usuarioId(auth), corpo.inicio());
        return ResponseEntity.accepted()
                .location(URI.create("/api/agendamentos/" + a.getId()))
                .body(resumo(a));
    }

    @GetMapping
    public List<Map<String, Object>> listar(Authentication auth) {
        return service.listarDoUsuario(usuarioId(auth)).stream().map(AgendamentoController::resumo).toList();
    }

    @GetMapping("/{id}")
    public Map<String, Object> buscar(@PathVariable UUID id, Authentication auth) {
        boolean operador = auth.getAuthorities().stream()
                .anyMatch(g -> g.getAuthority().equals("ROLE_OPERADOR") || g.getAuthority().equals("ROLE_ADMIN"));
        return resumo(service.buscar(usuarioId(auth), id, operador));
    }

    @PostMapping("/{id}/cancelamento")
    public ResponseEntity<Map<String, Object>> cancelar(@PathVariable UUID id, Authentication auth) {
        return ResponseEntity.accepted().body(resumo(service.cancelar(usuarioId(auth), id)));
    }

    @GetMapping("/{id}/qr")
    public Map<String, String> qr(@PathVariable UUID id, Authentication auth) {
        return Map.of("qr", service.gerarQr(usuarioId(auth), id));
    }

    static UUID usuarioId(Authentication auth) {
        return UUID.fromString(auth.getName());
    }

    static Map<String, Object> resumo(Agendamento a) {
        var mapa = new java.util.LinkedHashMap<String, Object>();
        mapa.put("id", a.getId().toString());
        mapa.put("usuarioId", a.getUsuarioId().toString());
        mapa.put("inicio", a.getInicio().toString());
        mapa.put("fim", a.getFim().toString());
        mapa.put("status", a.getStatus().name());
        mapa.put("valor", a.getValor());
        mapa.put("expiraEm", a.getExpiraEm().toString());
        mapa.put("confirmadoEm", a.getConfirmadoEm() == null ? null : a.getConfirmadoEm().toString());
        mapa.put("percentualReembolso", a.getPercentualReembolso());
        return mapa;
    }
}
