package com.estacionamento.parking.service;

import java.util.UUID;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.estacionamento.parking.config.NegocioProperties;
import com.estacionamento.parking.domain.Role;
import com.estacionamento.parking.domain.Usuario;
import com.estacionamento.parking.repository.UsuarioRepository;

/** Cria o administrador e o operador iniciais a partir do .env, se ainda não existirem. */
@Component
public class SeedService implements ApplicationRunner {

    private final UsuarioRepository usuarios;
    private final PasswordEncoder encoder;
    private final NegocioProperties props;

    public SeedService(UsuarioRepository usuarios, PasswordEncoder encoder, NegocioProperties props) {
        this.usuarios = usuarios;
        this.encoder = encoder;
        this.props = props;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        criarSeNecessario(props.adminEmail(), props.adminSenha(), Role.ADMIN);
        criarSeNecessario(props.operadorEmail(), props.operadorSenha(), Role.OPERADOR);
    }

    private void criarSeNecessario(String email, String senha, Role role) {
        if (email == null || email.isBlank() || senha == null || senha.isBlank()) {
            return;
        }
        if (usuarios.findByEmail(email).isEmpty()) {
            usuarios.save(new Usuario(UUID.randomUUID(), email, encoder.encode(senha), role));
        }
    }
}
