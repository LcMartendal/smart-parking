package com.estacionamento.parking.domain;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

/** Cobrança interna do Parking. Cada transição é condicional e controlada pela versão. */
@Entity
@Table(name = "cobranca")
public class Cobranca {

    @Id
    private UUID id;

    @Column(name = "agendamento_id", nullable = false, unique = true)
    private UUID agendamentoId;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal valor;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal estornado;

    @Column(name = "valor_estorno", precision = 10, scale = 2)
    private BigDecimal valorEstorno;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 24)
    private StatusCobranca status;

    @Column(name = "criada_em", nullable = false)
    private Instant criadaEm;

    @Column(name = "atualizada_em", nullable = false)
    private Instant atualizadaEm;

    @Version
    private long versao;

    protected Cobranca() {
    }

    public Cobranca(UUID id, UUID agendamentoId, BigDecimal valor, Instant agora) {
        this.id = id;
        this.agendamentoId = agendamentoId;
        this.valor = valor;
        this.estornado = BigDecimal.ZERO;
        this.status = StatusCobranca.PENDENTE;
        this.criadaEm = agora;
        this.atualizadaEm = agora;
    }

    public void enviarAoBanco(Instant agora) {
        this.status = StatusCobranca.ENVIADA_AO_BANCO;
        this.atualizadaEm = agora;
    }

    public void aprovar(Instant agora) {
        this.status = StatusCobranca.APROVADA;
        this.atualizadaEm = agora;
    }

    public void recusar(Instant agora) {
        this.status = StatusCobranca.RECUSADA;
        this.atualizadaEm = agora;
    }

    public void solicitarEstorno(BigDecimal valor, Instant agora) {
        this.valorEstorno = valor;
        this.status = StatusCobranca.ESTORNO_PENDENTE;
        this.atualizadaEm = agora;
    }

    public void estornar(Instant agora) {
        this.estornado = this.valorEstorno;
        this.status = StatusCobranca.ESTORNADA;
        this.atualizadaEm = agora;
    }

    public UUID getId() { return id; }
    public UUID getAgendamentoId() { return agendamentoId; }
    public BigDecimal getValor() { return valor; }
    public BigDecimal getValorEstorno() { return valorEstorno; }
    public StatusCobranca getStatus() { return status; }
}
