package com.estacionamento.parking.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.estacionamento.parking.domain.TransacaoBanco;

public interface TransacaoBancoRepository extends JpaRepository<TransacaoBanco, UUID> {
}
