package com.estacionamento.parking.web;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.estacionamento.parking.service.AgendamentoService;

@RestController
@RequestMapping("/api/operador")
public class OperadorController {

    private final AgendamentoService service;

    public OperadorController(AgendamentoService service) {
        this.service = service;
    }

    @GetMapping("/agendamentos")
    public List<Map<String, Object>> doDia(@RequestParam LocalDate dia) {
        return service.listarDoDia(dia).stream().map(AgendamentoController::resumo).toList();
    }
}
