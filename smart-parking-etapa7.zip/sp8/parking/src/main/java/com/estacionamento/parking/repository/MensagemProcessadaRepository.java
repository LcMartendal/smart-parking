package com.estacionamento.parking.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.estacionamento.parking.domain.MensagemProcessada;

public interface MensagemProcessadaRepository extends JpaRepository<MensagemProcessada, UUID> {
}
