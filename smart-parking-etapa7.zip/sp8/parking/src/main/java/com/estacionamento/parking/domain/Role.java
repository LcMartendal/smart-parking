package com.estacionamento.parking.domain;

public enum Role {
    USUARIO, OPERADOR, ADMIN
}
