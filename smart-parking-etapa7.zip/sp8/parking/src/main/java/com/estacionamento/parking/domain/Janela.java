package com.estacionamento.parking.domain;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Capacidade por horário. As alterações de ocupação são feitas por UPDATE condicional no repositório. */
@Entity
@Table(name = "janela")
public class Janela {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private Instant inicio;

    @Column(nullable = false)
    private int ocupadas;

    @Column(nullable = false)
    private int capacidade;

    protected Janela() {
    }

    public Long getId() { return id; }
    public Instant getInicio() { return inicio; }
    public int getOcupadas() { return ocupadas; }
    public int getCapacidade() { return capacidade; }
}
