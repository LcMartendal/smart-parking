package com.estacionamento.parking.banco;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.Random;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.estacionamento.parking.config.NegocioProperties;
import com.estacionamento.parking.domain.TransacaoBanco;
import com.estacionamento.parking.repository.TransacaoBancoRepository;

/** Simulação do banco: latência e recusa configuráveis (R5, F1, F7). Não segura transação durante a espera. */
@Component
public class BancoSimulado implements BancoAdapter {

    private final TransacaoBancoRepository transacoes;
    private final NegocioProperties props;
    private final Clock clock;
    private final Random random = new Random();

    public BancoSimulado(TransacaoBancoRepository transacoes, NegocioProperties props, Clock clock) {
        this.transacoes = transacoes;
        this.props = props;
        this.clock = clock;
    }

    @Override
    public Resultado cobrar(UUID chave, BigDecimal valor) {
        return executar("COBRANCA", chave, valor, true);
    }

    @Override
    public Resultado estornar(UUID chave, BigDecimal valor) {
        return executar("ESTORNO", chave, valor, false);
    }

    private Resultado executar(String tipo, UUID chave, BigDecimal valor, boolean podeRecusar) {
        var ja = transacoes.findById(chave);
        if (ja.isPresent()) {
            return new Resultado(ja.get().isAprovada(), "reaproveitado pela chave de idempotência");
        }
        esperar(latencia());
        var depois = transacoes.findById(chave);
        if (depois.isPresent()) {
            return new Resultado(depois.get().isAprovada(), "reaproveitado pela chave de idempotência");
        }
        boolean aprovada = !podeRecusar || random.nextDouble() >= props.bancoTaxaFalha();
        transacoes.save(new TransacaoBanco(chave, tipo, valor, aprovada, clock.instant()));
        return new Resultado(aprovada, aprovada ? "aprovada" : "recusada pelo banco");
    }

    private long latencia() {
        long min = props.bancoLatenciaMinMs();
        long max = Math.max(min, props.bancoLatenciaMaxMs());
        return min + random.nextLong(max - min + 1);
    }

    private static void esperar(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("interrompido na espera do banco", e);
        }
    }
}
