package com.estacionamento.parking.banco;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Contrato com o banco. O Parking só conhece estes dois pedidos. A implementação atual é simulada.
 * Ambos os métodos são idempotentes pela chave: a mesma chave devolve sempre o mesmo resultado.
 */
public interface BancoAdapter {

    Resultado cobrar(UUID chaveIdempotencia, BigDecimal valor);

    Resultado estornar(UUID chaveIdempotencia, BigDecimal valor);

    record Resultado(boolean aprovada, String motivo) {
    }
}
