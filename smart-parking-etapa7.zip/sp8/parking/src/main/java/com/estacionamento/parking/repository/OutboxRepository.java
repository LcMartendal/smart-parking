package com.estacionamento.parking.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.estacionamento.parking.domain.OutboxEvento;

public interface OutboxRepository extends JpaRepository<OutboxEvento, UUID> {

    List<OutboxEvento> findTop100ByPublicadoEmIsNullOrderByCriadoEmAsc();
}
