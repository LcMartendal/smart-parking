package com.estacionamento.parking.service;

import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.estacionamento.parking.banco.BancoAdapter;
import com.estacionamento.parking.config.NegocioProperties;

import jakarta.annotation.PreDestroy;

/** Envia as cobranças ao banco em threads virtuais. Cobranças travadas são reenviadas com a mesma chave. */
@Component
public class CobrancaWorker {

    private static final Logger log = LoggerFactory.getLogger(CobrancaWorker.class);

    private final CobrancaProcessor processor;
    private final BancoAdapter banco;
    private final NegocioProperties props;
    private final Clock clock;
    private final ExecutorService pool = Executors.newVirtualThreadPerTaskExecutor();

    public CobrancaWorker(CobrancaProcessor processor, BancoAdapter banco, NegocioProperties props, Clock clock) {
        this.processor = processor;
        this.banco = banco;
        this.props = props;
        this.clock = clock;
    }

    @Scheduled(fixedDelayString = "${negocio.worker-intervalo-ms:1000}")
    public void ciclo() {
        Instant limite = clock.instant().minus(props.recuperacaoCobrancaSegundos(), ChronoUnit.SECONDS);
        for (CobrancaProcessor.Tarefa t : processor.reservar(limite)) {
            pool.submit(() -> executar(t));
        }
    }

    private void executar(CobrancaProcessor.Tarefa t) {
        try {
            if (t.estorno()) {
                banco.estornar(t.chave(), t.valor());
                processor.concluirEstorno(t.cobrancaId());
            } else {
                BancoAdapter.Resultado r = banco.cobrar(t.chave(), t.valor());
                processor.concluirCobranca(t.cobrancaId(), r.aprovada());
            }
        } catch (RuntimeException e) {
            log.warn("cobrança {} não concluída nesta tentativa; será retomada: {}", t.cobrancaId(), e.toString());
        }
    }

    @PreDestroy
    void fechar() {
        pool.shutdownNow();
    }
}
