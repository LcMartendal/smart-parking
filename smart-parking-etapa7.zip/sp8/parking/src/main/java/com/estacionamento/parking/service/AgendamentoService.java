package com.estacionamento.parking.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.estacionamento.parking.config.NegocioProperties;
import com.estacionamento.parking.domain.Agendamento;
import com.estacionamento.parking.domain.Cobranca;
import com.estacionamento.parking.domain.StatusAgendamento;
import com.estacionamento.parking.messaging.OutboxService;
import com.estacionamento.parking.repository.AgendamentoRepository;
import com.estacionamento.parking.repository.CobrancaRepository;
import com.estacionamento.parking.repository.JanelaRepository;
import com.estacionamento.parking.security.JwtService;

/** Saga do agendamento no Parking. A cobrança é interna; a pré-autorização é avisada ao Parking Control. */
@Service
public class AgendamentoService {

    private final AgendamentoRepository agendamentos;
    private final CobrancaRepository cobrancas;
    private final JanelaRepository janelas;
    private final OutboxService outbox;
    private final JwtService jwt;
    private final NegocioProperties props;
    private final Clock clock;

    public AgendamentoService(AgendamentoRepository agendamentos, CobrancaRepository cobrancas,
                              JanelaRepository janelas, OutboxService outbox, JwtService jwt,
                              NegocioProperties props, Clock clock) {
        this.agendamentos = agendamentos;
        this.cobrancas = cobrancas;
        this.janelas = janelas;
        this.outbox = outbox;
        this.jwt = jwt;
        this.props = props;
        this.clock = clock;
    }

    /** RF-02 e RF-03: reserva a vaga, cria a cobrança pendente e avisa o Parking Control (compensação em dois serviços). */
    @Transactional
    public Agendamento criar(UUID usuarioId, Instant inicioSolicitado) {
        Instant agora = clock.instant();
        Instant inicio = inicioSolicitado.truncatedTo(ChronoUnit.HOURS);
        if (inicio.isBefore(agora.truncatedTo(ChronoUnit.HOURS))) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "horário já passou");
        }
        janelas.inserirSeAusente(inicio, props.vagasPorJanela());
        if (janelas.reservarVaga(inicio) == 0) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "sem vagas nesta janela");
        }
        Agendamento a = new Agendamento(UUID.randomUUID(), usuarioId, inicio,
                inicio.plus(props.janelaAgendamentoMin(), ChronoUnit.MINUTES), props.tarifa(),
                agora, agora.plus(props.prazoPagamentoMin(), ChronoUnit.MINUTES));
        agendamentos.save(a);
        cobrancas.save(new Cobranca(UUID.randomUUID(), a.getId(), a.getValor(), agora));
        outbox.enfileirar("AgendamentoCriado", "agendamento.criado", a.getId(), Map.of(
                "agendamentoId", a.getId().toString(),
                "usuarioId", usuarioId.toString(),
                "inicio", a.getInicio().toString(),
                "fim", a.getFim().toString(),
                "expiraEm", a.getExpiraEm().toString()));
        return a;
    }

    /** RF-07 e RN-04 a RN-06: cancelamento com reembolso. O estorno é feito pelo worker. */
    @Transactional
    public Agendamento cancelar(UUID usuarioId, UUID id) {
        Agendamento a = agendamentos.findByIdAndUsuarioId(id, usuarioId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "agendamento não encontrado"));
        if (a.getStatus() != StatusAgendamento.CONFIRMADO) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "só agendamento confirmado pode ser cancelado");
        }
        Instant agora = clock.instant();
        if (!agora.isBefore(a.getInicio())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "cancelamento só é permitido antes do início");
        }
        boolean dentroDaJanela = !agora.isAfter(a.getConfirmadoEm().plus(props.cancelamentoJanelaMin(), ChronoUnit.MINUTES));
        BigDecimal percentual = dentroDaJanela ? BigDecimal.ONE : props.cancelamentoPercentualTardio();
        BigDecimal estorno = a.getValor().multiply(percentual).setScale(2, RoundingMode.HALF_UP);

        if (estorno.signum() == 0) {
            janelas.liberarVaga(a.getJanelaInicio());
            a.marcarCancelado(BigDecimal.ZERO);
            outbox.enfileirar("AgendamentoCancelado", "agendamento.cancelado", a.getId(), Map.of(
                    "agendamentoId", a.getId().toString(),
                    "usuarioId", usuarioId.toString(),
                    "motivo", "CANCELAMENTO_SEM_REEMBOLSO",
                    "percentualReembolso", BigDecimal.ZERO));
        } else {
            a.marcarCancelamento(percentual);
            cobrancas.findByAgendamentoId(a.getId())
                    .orElseThrow(() -> new IllegalStateException("agendamento sem cobrança: " + a.getId()))
                    .solicitarEstorno(estorno, agora);
        }
        return a;
    }

    /** RF-06: expira agendamentos sem pagamento no prazo (job a cada 5 s). */
    @Transactional
    public void expirarVencidos() {
        Instant agora = clock.instant();
        for (Agendamento a : agendamentos.findByStatusAndExpiraEmBefore(StatusAgendamento.AGUARDANDO_PAGAMENTO, agora)) {
            janelas.liberarVaga(a.getJanelaInicio());
            a.expirar();
            outbox.enfileirar("AgendamentoExpirado", "agendamento.expirado", a.getId(), Map.of(
                    "agendamentoId", a.getId().toString(),
                    "usuarioId", a.getUsuarioId().toString()));
        }
    }

    @Transactional(readOnly = true)
    public List<Agendamento> listarDoUsuario(UUID usuarioId) {
        return agendamentos.findByUsuarioIdOrderByInicioDesc(usuarioId);
    }

    @Transactional(readOnly = true)
    public Agendamento buscar(UUID usuarioId, UUID id, boolean operador) {
        var encontrado = operador ? agendamentos.findById(id) : agendamentos.findByIdAndUsuarioId(id, usuarioId);
        return encontrado.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "agendamento não encontrado"));
    }

    @Transactional(readOnly = true)
    public List<Agendamento> listarDoDia(LocalDate dia) {
        Instant inicio = dia.atStartOfDay(ZoneOffset.UTC).toInstant();
        return agendamentos.findByInicioBetweenOrderByInicioAsc(inicio, inicio.plus(1, ChronoUnit.DAYS));
    }

    @Transactional(readOnly = true)
    public String gerarQr(UUID usuarioId, UUID id) {
        Agendamento a = agendamentos.findByIdAndUsuarioId(id, usuarioId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "agendamento não encontrado"));
        if (a.getStatus() != StatusAgendamento.CONFIRMADO) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "QR disponível só para agendamento confirmado");
        }
        return jwt.emitirQr(a.getId(), usuarioId, a.getFim());
    }
}
