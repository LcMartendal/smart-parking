package com.estacionamento.parking.config;

import java.net.URI;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;

/** Lê as chaves de JWT e QR do Secrets Manager na inicialização. Sem elas, o serviço não sobe. */
@Configuration
public class ChavesConfig {

    public record Chaves(String jwt, String qr) {
    }

    @Bean
    Chaves chaves(@Value("${aws.endpoint}") String endpoint, @Value("${aws.region}") String region) {
        var builder = SecretsManagerClient.builder().region(Region.of(region));
        if (!endpoint.isBlank()) {
            builder.endpointOverride(URI.create(endpoint));
        }
        try (var sm = builder.build()) {
            return new Chaves(lerSegredo(sm, "estacionamento/jwt-key"), lerSegredo(sm, "estacionamento/qr-key"));
        }
    }

    private static String lerSegredo(SecretsManagerClient sm, String nome) {
        return sm.getSecretValue(GetSecretValueRequest.builder().secretId(nome).build()).secretString();
    }
}
