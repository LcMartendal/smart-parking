package com.estacionamento.parking.domain;

public enum StatusCobranca {
    PENDENTE, ENVIADA_AO_BANCO, APROVADA, RECUSADA, ESTORNO_PENDENTE, ESTORNADA
}
