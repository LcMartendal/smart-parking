package com.estacionamento.parking.domain;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

@Entity
@Table(name = "agendamento")
public class Agendamento {

    @Id
    private UUID id;

    @Column(name = "usuario_id", nullable = false)
    private UUID usuarioId;

    @Column(nullable = false)
    private Instant inicio;

    @Column(nullable = false)
    private Instant fim;

    @Column(name = "janela_inicio", nullable = false)
    private Instant janelaInicio;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private StatusAgendamento status;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal valor;

    @Column(name = "criado_em", nullable = false)
    private Instant criadoEm;

    @Column(name = "expira_em", nullable = false)
    private Instant expiraEm;

    @Column(name = "confirmado_em")
    private Instant confirmadoEm;

    @Column(name = "percentual_reembolso", precision = 4, scale = 2)
    private BigDecimal percentualReembolso;

    /** Controle de concorrência otimista: duas transições simultâneas não se sobrescrevem. */
    @Version
    private long versao;

    protected Agendamento() {
    }

    public Agendamento(UUID id, UUID usuarioId, Instant inicio, Instant fim, BigDecimal valor,
                       Instant criadoEm, Instant expiraEm) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.inicio = inicio;
        this.fim = fim;
        this.janelaInicio = inicio;
        this.status = StatusAgendamento.AGUARDANDO_PAGAMENTO;
        this.valor = valor;
        this.criadoEm = criadoEm;
        this.expiraEm = expiraEm;
    }

    public void confirmar(Instant quando) {
        this.status = StatusAgendamento.CONFIRMADO;
        this.confirmadoEm = quando;
    }

    public void marcarCancelamento(BigDecimal percentual) {
        this.status = StatusAgendamento.CANCELAMENTO_SOLICITADO;
        this.percentualReembolso = percentual;
    }

    public void marcarCancelado(BigDecimal percentual) {
        this.status = StatusAgendamento.CANCELADO;
        this.percentualReembolso = percentual;
    }

    public void expirar() {
        this.status = StatusAgendamento.EXPIRADO;
    }

    public UUID getId() { return id; }
    public UUID getUsuarioId() { return usuarioId; }
    public Instant getInicio() { return inicio; }
    public Instant getFim() { return fim; }
    public Instant getJanelaInicio() { return janelaInicio; }
    public StatusAgendamento getStatus() { return status; }
    public BigDecimal getValor() { return valor; }
    public Instant getCriadoEm() { return criadoEm; }
    public Instant getExpiraEm() { return expiraEm; }
    public Instant getConfirmadoEm() { return confirmadoEm; }
    public BigDecimal getPercentualReembolso() { return percentualReembolso; }
}
