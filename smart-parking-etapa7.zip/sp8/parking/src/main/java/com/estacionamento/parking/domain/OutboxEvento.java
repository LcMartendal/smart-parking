package com.estacionamento.parking.domain;

import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Evento gravado na mesma transação da mudança de estado e publicado depois pelo relay. */
@Entity
@Table(name = "outbox")
public class OutboxEvento {

    @Id
    private UUID id;

    @Column(nullable = false)
    private String tipo;

    @Column(name = "routing_key", nullable = false)
    private String routingKey;

    @Column(nullable = false, columnDefinition = "text")
    private String payload;

    @Column(name = "criado_em", nullable = false)
    private Instant criadoEm;

    @Column(name = "publicado_em")
    private Instant publicadoEm;

    protected OutboxEvento() {
    }

    public OutboxEvento(UUID id, String tipo, String routingKey, String payload, Instant criadoEm) {
        this.id = id;
        this.tipo = tipo;
        this.routingKey = routingKey;
        this.payload = payload;
        this.criadoEm = criadoEm;
    }

    public void marcarPublicado(Instant quando) {
        this.publicadoEm = quando;
    }

    public UUID getId() { return id; }
    public String getRoutingKey() { return routingKey; }
    public String getPayload() { return payload; }
}
