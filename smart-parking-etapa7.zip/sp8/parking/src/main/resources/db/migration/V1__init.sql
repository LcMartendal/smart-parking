create table usuario (
  id uuid primary key,
  email varchar(255) not null unique,
  senha_hash varchar(100) not null,
  role varchar(20) not null
);

create table janela (
  id bigserial primary key,
  inicio timestamptz not null unique,
  ocupadas integer not null default 0,
  capacidade integer not null,
  constraint ck_janela_ocupadas check (ocupadas >= 0 and ocupadas <= capacidade)
);

create table agendamento (
  id uuid primary key,
  usuario_id uuid not null references usuario(id),
  inicio timestamptz not null,
  fim timestamptz not null,
  janela_inicio timestamptz not null,
  status varchar(32) not null,
  valor numeric(10,2) not null,
  criado_em timestamptz not null,
  expira_em timestamptz not null,
  confirmado_em timestamptz,
  percentual_reembolso numeric(4,2),
  versao bigint not null default 0
);
create index ix_agendamento_status_expira on agendamento(status, expira_em);
create index ix_agendamento_usuario on agendamento(usuario_id);

create table outbox (
  id uuid primary key,
  tipo varchar(64) not null,
  routing_key varchar(128) not null,
  payload text not null,
  criado_em timestamptz not null,
  publicado_em timestamptz
);
create index ix_outbox_pendente on outbox(criado_em) where publicado_em is null;

create table mensagem_processada (
  message_id uuid primary key,
  processado_em timestamptz not null
);
