create table cobranca (
  id uuid primary key,
  agendamento_id uuid not null unique references agendamento(id),
  valor numeric(10,2) not null,
  estornado numeric(10,2) not null default 0,
  valor_estorno numeric(10,2),
  status varchar(24) not null,
  criada_em timestamptz not null,
  atualizada_em timestamptz not null,
  versao bigint not null default 0
);
create index ix_cobranca_status on cobranca(status, criada_em);

create table transacao_banco (
  chave uuid primary key,
  tipo varchar(16) not null,
  valor numeric(10,2) not null,
  aprovada boolean not null,
  criada_em timestamptz not null
);
