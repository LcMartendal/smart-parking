import hmac
from dataclasses import dataclass

import jwt
from fastapi import Depends, Header, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.segredos import Chaves

bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class UsuarioAutenticado:
    id: str
    role: str


def _chaves(request: Request) -> Chaves:
    return request.app.state.chaves


def usuario_atual(
    request: Request,
    credenciais: HTTPAuthorizationCredentials | None = Depends(bearer),
) -> UsuarioAutenticado:
    if credenciais is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "token ausente")
    try:
        payload = jwt.decode(credenciais.credentials, _chaves(request).jwt, algorithms=["HS256"],
                             options={"require": ["exp", "sub"]})
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "token inválido")
    return UsuarioAutenticado(id=payload["sub"], role=payload.get("role", "USUARIO"))


def exigir_perfil(*perfis: str):
    def dependencia(usuario: UsuarioAutenticado = Depends(usuario_atual)) -> UsuarioAutenticado:
        if usuario.role not in perfis:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "perfil sem permissão")
        return usuario

    return dependencia


def dispositivo_autorizado(request: Request, x_device_key: str | None = Header(default=None)) -> None:
    if not x_device_key or not hmac.compare_digest(x_device_key, _chaves(request).device):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "dispositivo não autorizado")


def validar_qr(token: str, chave_qr: str) -> dict:
    """QR assinado pelo Parking. Confere assinatura e validade (exp = fim da janela)."""
    try:
        return jwt.decode(token, chave_qr, algorithms=["HS256"], options={"require": ["exp", "sub"]})
    except jwt.PyJWTError as e:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, f"QR inválido: {e}")
