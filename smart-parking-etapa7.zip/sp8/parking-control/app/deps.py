from collections.abc import Iterator

from fastapi import Request
from sqlalchemy.orm import Session

from app.db import SessionLocal


def get_db() -> Iterator[Session]:
    with SessionLocal() as db:
        yield db


def get_storage(request: Request):
    return request.app.state.armazenamento


def get_chaves(request: Request):
    return request.app.state.chaves
