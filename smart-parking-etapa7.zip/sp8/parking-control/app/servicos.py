"""Regras do Parking Control: projeção de agendamentos, entrada e saída, notas e limpeza."""
import base64
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.armazenamento import Armazenamento
from app.db import SessionLocal
from app.models import AgendamentoProjetado, MensagemProcessada, Nota, OutboxEvento, Sessao
from app.segredos import Chaves
from app.seguranca import validar_qr


@dataclass
class Resultado:
    abrir: bool
    motivo: str
    nota_id: str | None = None


def agora() -> datetime:
    return datetime.now(UTC)


def _em_dt(texto: str) -> datetime:
    return datetime.fromisoformat(texto.replace("Z", "+00:00"))


def enfileirar(db: Session, tipo: str, routing_key: str, correlation_id: uuid.UUID, payload: dict) -> None:
    """Grava o evento na outbox, na mesma transação da mudança de estado."""
    import json

    momento = agora()
    message_id = uuid.uuid4()
    envelope = {
        "messageId": str(message_id),
        "correlationId": str(correlation_id),
        "type": tipo,
        "version": 1,
        "occurredAt": momento.isoformat(),
        "payload": payload,
    }
    db.add(OutboxEvento(id=message_id, tipo=tipo, routing_key=routing_key,
                        payload=json.dumps(envelope, ensure_ascii=False), criado_em=momento))


# ---------- projeção (consumo de eventos de agendamento) ----------

def processar_evento_agendamento(evento: dict) -> None:
    """Idempotente por messageId, na mesma transação do efeito (R1)."""
    mid = uuid.UUID(evento["messageId"])
    p = evento["payload"]
    with SessionLocal() as db, db.begin():
        if db.get(MensagemProcessada, mid) is not None:
            return
        db.add(MensagemProcessada(message_id=mid, processado_em=agora()))
        ag_id = uuid.UUID(p["agendamentoId"])
        tipo = evento["type"]
        if tipo == "AgendamentoConfirmado":
            row = db.get(AgendamentoProjetado, ag_id)
            if row is None:
                db.add(AgendamentoProjetado(id=ag_id, usuario_id=uuid.UUID(p["usuarioId"]),
                                            inicio=_em_dt(p["inicio"]), fim=_em_dt(p["fim"]), status="CONFIRMADO"))
            elif row.status != "CANCELADO":
                row.status = "CONFIRMADO"
        elif tipo in ("AgendamentoCancelado", "AgendamentoExpirado"):
            row = db.get(AgendamentoProjetado, ag_id)
            if row is not None:
                row.status = "CANCELADO" if tipo == "AgendamentoCancelado" else "EXPIRADO"


# ---------- catraca ----------

def registrar_entrada(db: Session, chaves: Chaves, storage: Armazenamento, qr: str,
                      foto_base64: str | None, cancela: str) -> Resultado:
    claims = validar_qr(qr, chaves.qr)
    ag_id = uuid.UUID(claims["sub"])
    proj = db.get(AgendamentoProjetado, ag_id)
    if proj is None or proj.status != "CONFIRMADO":
        return Resultado(False, "agendamento não confirmado")
    momento = agora()
    if momento >= proj.fim:
        return Resultado(False, "janela de agendamento encerrada")
    if db.scalar(select(Sessao.id).where(Sessao.agendamento_id == ag_id, Sessao.status == "ABERTA")):
        return Resultado(False, "já há entrada registrada para este agendamento")

    sessao = Sessao(agendamento_id=ag_id, usuario_id=proj.usuario_id, status="ABERTA", origem="QR",
                    entrada_em=momento)
    db.add(sessao)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        return Resultado(False, "já há entrada registrada para este agendamento")

    foto_key, foto_pendente = None, False
    if foto_base64:
        try:
            foto_key = f"fotos/{sessao.id}.jpg"
            storage.salvar_foto(foto_key, base64.b64decode(foto_base64))
            sessao.foto_key = foto_key
        except Exception:
            # A entrada não depende da foto: a nota fica pendente e a foto pode ser reenviada
            foto_key, foto_pendente = None, True

    nota = Nota(sessao_id=sessao.id, usuario_id=proj.usuario_id, agendamento_id=ag_id,
                foto_key=foto_key, foto_pendente=foto_pendente, emitida_em=momento,
                dados={"cancela": cancela, "inicio": proj.inicio.isoformat(), "fim": proj.fim.isoformat()})
    db.add(nota)
    enfileirar(db, "EntradaRegistrada", "acesso.entrada-registrada", ag_id, {
        "sessaoId": str(sessao.id), "agendamentoId": str(ag_id), "usuarioId": str(proj.usuario_id),
        "origem": "QR", "motivo": None, "fotoKey": foto_key, "registradaEm": momento.isoformat()})
    db.commit()
    return Resultado(True, "autorizado", str(nota.id))


def registrar_saida(db: Session, chaves: Chaves, qr: str) -> Resultado:
    claims = validar_qr(qr, chaves.qr)
    ag_id = uuid.UUID(claims["sub"])
    sessao = db.scalar(select(Sessao).where(Sessao.agendamento_id == ag_id, Sessao.status == "ABERTA"))
    if sessao is None:
        return Resultado(False, "sem entrada aberta para este agendamento")
    momento = agora()
    sessao.status, sessao.saida_em = "FECHADA", momento
    enfileirar(db, "SaidaRegistrada", "acesso.saida-registrada", ag_id, {
        "sessaoId": str(sessao.id), "agendamentoId": str(ag_id), "usuarioId": str(sessao.usuario_id),
        "registradaEm": momento.isoformat()})
    db.commit()
    return Resultado(True, "saída registrada")


def abertura_manual(db: Session, agendamento_id: uuid.UUID, motivo: str, operador_id: str) -> Resultado:
    """Fallback quando o QR falha: o operador abre a cancela. Fica registrado com o motivo."""
    proj = db.get(AgendamentoProjetado, agendamento_id)
    if proj is None or proj.status != "CONFIRMADO":
        raise HTTPException(status.HTTP_409_CONFLICT, "agendamento não confirmado")
    if db.scalar(select(Sessao.id).where(Sessao.agendamento_id == agendamento_id, Sessao.status == "ABERTA")):
        raise HTTPException(status.HTTP_409_CONFLICT, "já há entrada registrada")
    momento = agora()
    sessao = Sessao(agendamento_id=agendamento_id, usuario_id=proj.usuario_id, status="ABERTA",
                    origem="OPERADOR", motivo=f"{motivo} (operador {operador_id})", entrada_em=momento)
    db.add(sessao)
    db.flush()
    nota = Nota(sessao_id=sessao.id, usuario_id=proj.usuario_id, agendamento_id=agendamento_id,
                foto_key=None, foto_pendente=True, emitida_em=momento,
                dados={"origem": "OPERADOR", "motivo": motivo})
    db.add(nota)
    enfileirar(db, "EntradaRegistrada", "acesso.entrada-registrada", agendamento_id, {
        "sessaoId": str(sessao.id), "agendamentoId": str(agendamento_id), "usuarioId": str(proj.usuario_id),
        "origem": "OPERADOR", "motivo": motivo, "fotoKey": None, "registradaEm": momento.isoformat()})
    db.commit()
    return Resultado(True, "abertura manual registrada", str(nota.id))


# ---------- consultas e notas ----------

def listar_acessos(db: Session, dia) -> list[Sessao]:
    inicio = datetime(dia.year, dia.month, dia.day, tzinfo=UTC)
    return list(db.scalars(select(Sessao).where(Sessao.entrada_em >= inicio,
                                                Sessao.entrada_em < inicio + timedelta(days=1))
                           .order_by(Sessao.entrada_em)))


def listar_notas(db: Session, usuario_id: str) -> list[Nota]:
    return list(db.scalars(select(Nota).where(Nota.usuario_id == uuid.UUID(usuario_id))
                           .order_by(Nota.emitida_em.desc())))


def ler_foto(db: Session, storage: Armazenamento, nota_id: uuid.UUID, usuario_id: str, pode_ver_todas: bool) -> bytes:
    nota = db.get(Nota, nota_id)
    if nota is None or (not pode_ver_todas and str(nota.usuario_id) != usuario_id):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "nota não encontrada")
    if not nota.foto_key:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "esta nota não tem foto")
    return storage.ler_foto(nota.foto_key)


def limpar_notas(db: Session, storage: Armazenamento, ate: datetime) -> int:
    """Limpeza feita pelo administrador: apaga fotos e notas emitidas antes da data."""
    notas = list(db.scalars(select(Nota).where(Nota.emitida_em < ate)))
    for nota in notas:
        if nota.foto_key:
            storage.apagar(nota.foto_key)
        db.delete(nota)
    db.commit()
    return len(notas)


# ---------- relay da outbox (usado pela mensageria) ----------

def listar_pendentes() -> list[tuple[uuid.UUID, str, str]]:
    with SessionLocal() as db:
        rows = db.scalars(select(OutboxEvento).where(OutboxEvento.publicado_em.is_(None))
                          .order_by(OutboxEvento.criado_em).limit(100)).all()
        return [(r.id, r.routing_key, r.payload) for r in rows]


def marcar_publicado(evento_id: uuid.UUID) -> None:
    with SessionLocal() as db, db.begin():
        row = db.get(OutboxEvento, evento_id)
        if row is not None:
            row.publicado_em = agora()
