import uuid
from datetime import date

from fastapi import APIRouter, Depends

from app import servicos
from app.deps import get_db
from app.schemas import AberturaManual
from app.seguranca import UsuarioAutenticado, exigir_perfil

router = APIRouter(tags=["acessos"])


@router.get("/api/acessos")
def acessos_do_dia(dia: date, db=Depends(get_db), _=Depends(exigir_perfil("OPERADOR", "ADMIN"))):
    return [
        {"sessaoId": str(s.id), "agendamentoId": str(s.agendamento_id), "status": s.status,
         "origem": s.origem, "motivo": s.motivo, "entradaEm": s.entrada_em.isoformat(),
         "saidaEm": s.saida_em.isoformat() if s.saida_em else None, "fotoKey": s.foto_key}
        for s in servicos.listar_acessos(db, dia)
    ]


@router.post("/api/operador/abertura-manual")
def abertura_manual(corpo: AberturaManual, db=Depends(get_db),
                    operador: UsuarioAutenticado = Depends(exigir_perfil("OPERADOR", "ADMIN"))):
    r = servicos.abertura_manual(db, corpo.agendamento_id, corpo.motivo, operador.id)
    return {"abrir": r.abrir, "motivo": r.motivo, "notaId": r.nota_id}
