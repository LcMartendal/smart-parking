from datetime import UTC, datetime

from fastapi import APIRouter, Depends

from app import servicos
from app.deps import get_db, get_storage
from app.seguranca import exigir_perfil

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.post("/notas/limpeza")
def limpar(ate: datetime, db=Depends(get_db), storage=Depends(get_storage),
           _=Depends(exigir_perfil("ADMIN"))):
    if ate.tzinfo is None:
        ate = ate.replace(tzinfo=UTC)
    return {"removidas": servicos.limpar_notas(db, storage, ate)}
