from fastapi import APIRouter, Depends

from app import servicos
from app.deps import get_chaves, get_db, get_storage
from app.schemas import CatracaEntrada, CatracaSaida
from app.seguranca import dispositivo_autorizado

router = APIRouter(prefix="/api/catraca", tags=["catraca"], dependencies=[Depends(dispositivo_autorizado)])


@router.post("/entrada")
def entrada(corpo: CatracaEntrada, db=Depends(get_db), chaves=Depends(get_chaves), storage=Depends(get_storage)):
    r = servicos.registrar_entrada(db, chaves, storage, corpo.qr, corpo.foto, corpo.cancela)
    return {"abrir": r.abrir, "motivo": r.motivo, "notaId": r.nota_id}


@router.post("/saida")
def saida(corpo: CatracaSaida, db=Depends(get_db), chaves=Depends(get_chaves)):
    r = servicos.registrar_saida(db, chaves, corpo.qr)
    return {"abrir": r.abrir, "motivo": r.motivo}
