import uuid

from fastapi import APIRouter, Depends
from fastapi.responses import Response

from app import servicos
from app.deps import get_db, get_storage
from app.seguranca import UsuarioAutenticado, usuario_atual

router = APIRouter(prefix="/api/notas", tags=["notas"])


@router.get("")
def minhas_notas(db=Depends(get_db), usuario: UsuarioAutenticado = Depends(usuario_atual)):
    return [
        {"id": str(n.id), "agendamentoId": str(n.agendamento_id), "emitidaEm": n.emitida_em.isoformat(),
         "fotoPendente": n.foto_pendente, "temFoto": n.foto_key is not None, "dados": n.dados}
        for n in servicos.listar_notas(db, usuario.id)
    ]


@router.get("/{nota_id}/foto")
def foto(nota_id: uuid.UUID, db=Depends(get_db), storage=Depends(get_storage),
         usuario: UsuarioAutenticado = Depends(usuario_atual)):
    pode_ver_todas = usuario.role in ("OPERADOR", "ADMIN")
    conteudo = servicos.ler_foto(db, storage, nota_id, usuario.id, pode_ver_todas)
    return Response(content=conteudo, media_type="image/jpeg")
