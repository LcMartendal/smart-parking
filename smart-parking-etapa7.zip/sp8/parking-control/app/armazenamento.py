import boto3
from botocore.config import Config


class Armazenamento:
    """Fotos das entradas no S3. Path-style, porque o MiniStack usa o endpoint como caminho."""

    def __init__(self, bucket: str, endpoint_url: str | None, region: str):
        self.bucket = bucket
        self.s3 = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            region_name=region,
            config=Config(s3={"addressing_style": "path"}),
        )

    def salvar_foto(self, chave: str, conteudo: bytes) -> None:
        self.s3.put_object(Bucket=self.bucket, Key=chave, Body=conteudo, ContentType="image/jpeg")

    def ler_foto(self, chave: str) -> bytes:
        return self.s3.get_object(Bucket=self.bucket, Key=chave)["Body"].read()

    def apagar(self, chave: str) -> None:
        self.s3.delete_object(Bucket=self.bucket, Key=chave)
