import uuid
from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, Index, String, Text, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class AgendamentoProjetado(Base):
    """Cópia local dos agendamentos, alimentada pelos eventos (sem chamada síncrona ao Parking)."""

    __tablename__ = "agendamento_projetado"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True)
    usuario_id: Mapped[uuid.UUID]
    inicio: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    fim: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(32))


class Sessao(Base):
    __tablename__ = "sessao"
    __table_args__ = (
        # No máximo uma sessão aberta por agendamento (R2)
        Index("ux_sessao_aberta", "agendamento_id", unique=True, postgresql_where=text("status = 'ABERTA'")),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    agendamento_id: Mapped[uuid.UUID]
    usuario_id: Mapped[uuid.UUID]
    status: Mapped[str] = mapped_column(String(16))
    origem: Mapped[str] = mapped_column(String(16))
    motivo: Mapped[str | None] = mapped_column(String(255))
    entrada_em: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    saida_em: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    foto_key: Mapped[str | None] = mapped_column(String(255))


class Nota(Base):
    """Comprovante simulado da entrada. Não é nota fiscal eletrônica."""

    __tablename__ = "nota"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    sessao_id: Mapped[uuid.UUID] = mapped_column(unique=True)
    usuario_id: Mapped[uuid.UUID]
    agendamento_id: Mapped[uuid.UUID]
    foto_key: Mapped[str | None] = mapped_column(String(255))
    foto_pendente: Mapped[bool] = mapped_column(Boolean, default=False)
    emitida_em: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    dados: Mapped[dict] = mapped_column(JSON, default=dict)


class MensagemProcessada(Base):
    __tablename__ = "mensagem_processada"

    message_id: Mapped[uuid.UUID] = mapped_column(primary_key=True)
    processado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class OutboxEvento(Base):
    __tablename__ = "outbox"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True)
    tipo: Mapped[str] = mapped_column(String(64))
    routing_key: Mapped[str] = mapped_column(String(128))
    payload: Mapped[str] = mapped_column(Text)
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    publicado_em: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
