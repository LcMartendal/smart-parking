from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Configuração por variáveis de ambiente. Nomes de segredos e endpoints nunca ficam fixos no código."""

    model_config = SettingsConfigDict(extra="ignore")

    database_url: str = Field(validation_alias="DATABASE_URL")
    rabbitmq_url: str = Field(default="amqp://guest:guest@rabbitmq:5672/", validation_alias="RABBITMQ_URL")
    aws_endpoint_url: str | None = Field(default=None, validation_alias="AWS_ENDPOINT_URL")
    aws_region: str = Field(default="sa-east-1", validation_alias="AWS_DEFAULT_REGION")
    bucket_comprovantes: str = Field(default="estacionamento-comprovantes", validation_alias="BUCKET_COMPROVANTES")
    secret_jwt_key: str = Field(default="estacionamento/jwt-key", validation_alias="SECRET_JWT_KEY")
    secret_qr_key: str = Field(default="estacionamento/qr-key", validation_alias="SECRET_QR_KEY")
    secret_device_key: str = Field(default="estacionamento/device-key", validation_alias="SECRET_DEVICE_KEY")
    exchange: str = Field(default="estacionamento", validation_alias="EXCHANGE")
    fila_agendamentos: str = "control.agendamentos"
    outbox_intervalo_s: float = Field(default=1.0, validation_alias="OUTBOX_INTERVALO_S")
    mensageria_habilitada: bool = Field(default=True, validation_alias="MENSAGERIA_HABILITADA")


@lru_cache
def get_settings() -> Settings:
    return Settings()
