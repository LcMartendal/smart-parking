"""Consumo de agendamentos e relay da outbox. Reconecta sozinho quando o broker cai (R6)."""
import asyncio
import json
import logging

import aio_pika

from app import servicos
from app.config import Settings

log = logging.getLogger("mensageria")

# Erros de payload: não são corrigidos por nova tentativa
PERMANENTES = (KeyError, TypeError, ValueError)


async def _conectar(url: str):
    while True:
        try:
            return await aio_pika.connect_robust(url)
        except Exception as e:
            log.warning("RabbitMQ indisponível; nova tentativa em 2 s: %s", e)
            await asyncio.sleep(2)


async def _tratar(msg) -> None:
    """Erro transitório (banco, S3, lock) é repetido com espera crescente, sem mandar a mensagem para a DLQ.
    Erro de payload (JSON ou campo inválido) é permanente: a mensagem é devolvida e, após o limite de
    tentativas do broker (x-delivery-limit=3), vai para a DLQ (F4)."""
    try:
        evento = json.loads(msg.body)
    except ValueError:
        log.error("payload não é JSON válido; reenvio até a DLQ")
        await msg.reject(requeue=True)
        return
    espera = 0.5
    while True:
        try:
            await asyncio.to_thread(servicos.processar_evento_agendamento, evento)
            break
        except PERMANENTES as e:
            log.error("evento inválido (%s); reenvio até a DLQ", e)
            await msg.reject(requeue=True)
            return
        except Exception as e:
            log.warning("erro transitório; nova tentativa em %.1f s: %s", espera, e)
            await asyncio.sleep(espera)
            espera = min(30.0, espera * 2)
    await msg.ack()


async def _consumir(s: Settings) -> None:
    while True:
        try:
            conexao = await _conectar(s.rabbitmq_url)
            async with conexao:
                canal = await conexao.channel()
                await canal.set_qos(prefetch_count=10)
                fila = await canal.get_queue(s.fila_agendamentos, ensure=False)
                async with fila.iterator() as itens:
                    async for msg in itens:
                        await _tratar(msg)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("consumo interrompido; reconectando: %s", e)
            await asyncio.sleep(2)


async def _relay(s: Settings) -> None:
    while True:
        try:
            conexao = await _conectar(s.rabbitmq_url)
            async with conexao:
                canal = await conexao.channel(publisher_confirms=True)
                exchange = await canal.get_exchange(s.exchange, ensure=False)
                while True:
                    for evento_id, routing_key, corpo in await asyncio.to_thread(servicos.listar_pendentes):
                        await exchange.publish(
                            aio_pika.Message(body=corpo.encode("utf-8"), content_type="application/json",
                                             message_id=str(evento_id),
                                             delivery_mode=aio_pika.DeliveryMode.PERSISTENT),
                            routing_key=routing_key)
                        await asyncio.to_thread(servicos.marcar_publicado, evento_id)
                    await asyncio.sleep(s.outbox_intervalo_s)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("relay pausado; eventos pendentes serão reenviados: %s", e)
            await asyncio.sleep(2)


def iniciar(s: Settings) -> list[asyncio.Task]:
    return [asyncio.create_task(_consumir(s), name="consumo"), asyncio.create_task(_relay(s), name="relay")]
