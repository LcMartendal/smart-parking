from dataclasses import dataclass

import boto3

from app.config import Settings


@dataclass(frozen=True)
class Chaves:
    jwt: str
    qr: str
    device: str


def carregar_chaves(s: Settings) -> Chaves:
    """Lê as chaves do Secrets Manager. Sem elas o serviço não sobe."""
    sm = boto3.client("secretsmanager", endpoint_url=s.aws_endpoint_url, region_name=s.aws_region)

    def ler(nome: str) -> str:
        return sm.get_secret_value(SecretId=nome)["SecretString"]

    return Chaves(jwt=ler(s.secret_jwt_key), qr=ler(s.secret_qr_key), device=ler(s.secret_device_key))
