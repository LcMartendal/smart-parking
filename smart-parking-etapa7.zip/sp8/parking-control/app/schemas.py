from uuid import UUID

from pydantic import BaseModel, Field


class CatracaEntrada(BaseModel):
    qr: str
    foto: str | None = Field(default=None, description="JPEG em base64, frente do carro")
    cancela: str = "entrada-1"


class CatracaSaida(BaseModel):
    qr: str


class AberturaManual(BaseModel):
    agendamento_id: UUID
    motivo: str = Field(min_length=3, max_length=255)
