import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app import mensageria
from app.armazenamento import Armazenamento
from app.config import get_settings
from app.db import engine
from app.models import Base
from app.routers import acessos, admin, catraca, notas
from app.segredos import carregar_chaves

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    app.state.chaves = carregar_chaves(s)
    app.state.armazenamento = Armazenamento(s.bucket_comprovantes, s.aws_endpoint_url, s.aws_region)
    Base.metadata.create_all(engine)
    tarefas = mensageria.iniciar(s) if s.mensageria_habilitada else []
    yield
    for t in tarefas:
        t.cancel()


app = FastAPI(title="Parking Control", version="0.1.0", lifespan=lifespan)
app.include_router(catraca.router)
app.include_router(acessos.router)
app.include_router(notas.router)
app.include_router(admin.router)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
