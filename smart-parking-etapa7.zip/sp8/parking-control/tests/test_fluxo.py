import base64
import uuid
from datetime import UTC, datetime, timedelta

import jwt
import pytest
from fastapi.testclient import TestClient

from app import servicos
from app.config import get_settings
from app.db import SessionLocal, engine
from app.main import app
from app.models import AgendamentoProjetado, Base, MensagemProcessada, Nota, OutboxEvento, Sessao
from app.segredos import carregar_chaves

CHAVES = carregar_chaves(get_settings())
FOTO = base64.b64encode(b"\xff\xd8\xff\xe0 foto-de-teste").decode()


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(autouse=True)
def banco_limpo():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    yield


def agora():
    return datetime.now(UTC)


def token_qr(ag_id, usuario_id, exp=None, chave=None):
    return jwt.encode({"sub": str(ag_id), "usuarioId": str(usuario_id), "jti": str(uuid.uuid4()),
                       "iat": agora(), "exp": exp or agora() + timedelta(hours=1)},
                      chave or CHAVES.qr, algorithm="HS256")


def token_usuario(usuario_id, role="USUARIO"):
    return jwt.encode({"sub": str(usuario_id), "role": role, "exp": agora() + timedelta(hours=1)},
                      CHAVES.jwt, algorithm="HS256")


def evento(tipo, payload, message_id=None):
    return {"messageId": str(message_id or uuid.uuid4()), "correlationId": str(uuid.uuid4()),
            "type": tipo, "version": 1, "occurredAt": agora().isoformat(), "payload": payload}


def confirmar(ag_id, usuario_id, inicio=None, fim=None):
    inicio = inicio or agora() - timedelta(minutes=5)
    fim = fim or agora() + timedelta(hours=1)
    servicos.processar_evento_agendamento(evento("AgendamentoConfirmado", {
        "agendamentoId": str(ag_id), "usuarioId": str(usuario_id),
        "inicio": inicio.isoformat(), "fim": fim.isoformat(), "confirmadoEm": agora().isoformat()}))
    return ag_id


DISPOSITIVO = {}


def dispositivo():
    return {"X-Device-Key": CHAVES.device}


def test_entrada_confirmada_abre_gera_nota_e_guarda_foto(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    r = client.post("/api/catraca/entrada", json={"qr": token_qr(ag, usuario), "foto": FOTO}, headers=dispositivo())
    assert r.status_code == 200, r.text
    assert r.json()["abrir"] is True
    nota_id = r.json()["notaId"]
    foto = client.get(f"/api/notas/{nota_id}/foto", headers={"Authorization": f"Bearer {token_usuario(usuario)}"})
    assert foto.status_code == 200
    assert foto.content == base64.b64decode(FOTO)


def test_segunda_entrada_do_mesmo_agendamento_e_negada(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    qr = token_qr(ag, usuario)
    assert client.post("/api/catraca/entrada", json={"qr": qr}, headers=dispositivo()).json()["abrir"] is True
    r = client.post("/api/catraca/entrada", json={"qr": qr}, headers=dispositivo())
    assert r.json()["abrir"] is False
    assert "já há entrada" in r.json()["motivo"]


def test_saida_fecha_a_sessao_e_nova_saida_e_negada(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    qr = token_qr(ag, usuario)
    client.post("/api/catraca/entrada", json={"qr": qr}, headers=dispositivo())
    assert client.post("/api/catraca/saida", json={"qr": qr}, headers=dispositivo()).json()["abrir"] is True
    assert client.post("/api/catraca/saida", json={"qr": qr}, headers=dispositivo()).json()["abrir"] is False


def test_qr_expirado_e_recusado(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    r = client.post("/api/catraca/entrada", json={"qr": token_qr(ag, usuario, exp=agora() - timedelta(minutes=1))},
                    headers=dispositivo())
    assert r.status_code == 401


def test_qr_com_assinatura_de_outra_chave_e_recusado(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    r = client.post("/api/catraca/entrada", json={"qr": token_qr(ag, usuario, chave="chave-falsa-123456789012345678")},
                    headers=dispositivo())
    assert r.status_code == 401


def test_catraca_sem_chave_de_dispositivo_e_recusada(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    r = client.post("/api/catraca/entrada", json={"qr": token_qr(ag, usuario)})
    assert r.status_code == 401


def test_agendamento_cancelado_nao_abre(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    servicos.processar_evento_agendamento(evento("AgendamentoCancelado", {
        "agendamentoId": str(ag), "usuarioId": str(usuario), "motivo": "X", "percentualReembolso": 1}))
    r = client.post("/api/catraca/entrada", json={"qr": token_qr(ag, usuario)}, headers=dispositivo())
    assert r.json()["abrir"] is False


def test_evento_duplicado_e_processado_uma_unica_vez():
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    mid = uuid.uuid4()
    ev = evento("AgendamentoConfirmado", {"agendamentoId": str(ag), "usuarioId": str(usuario),
                "inicio": agora().isoformat(), "fim": (agora() + timedelta(hours=1)).isoformat(),
                "confirmadoEm": agora().isoformat()}, message_id=mid)
    for _ in range(5):
        servicos.processar_evento_agendamento(ev)
    with SessionLocal() as db:
        assert db.query(MensagemProcessada).filter_by(message_id=mid).count() == 1
        assert db.query(AgendamentoProjetado).filter_by(id=ag).count() == 1


def test_foto_invalida_deixa_nota_pendente_e_a_entrada_segue(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    r = client.post("/api/catraca/entrada", json={"qr": token_qr(ag, usuario), "foto": "%%%nao-base64"},
                    headers=dispositivo())
    assert r.json()["abrir"] is True
    with SessionLocal() as db:
        nota = db.get(Nota, uuid.UUID(r.json()["notaId"]))
        assert nota.foto_pendente is True and nota.foto_key is None


def test_abertura_manual_exige_operador_e_fica_registrada(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    corpo = {"agendamento_id": str(ag), "motivo": "celular sem bateria"}
    negado = client.post("/api/operador/abertura-manual", json=corpo,
                         headers={"Authorization": f"Bearer {token_usuario(usuario)}"})
    assert negado.status_code == 403
    operador = uuid.uuid4()
    ok = client.post("/api/operador/abertura-manual", json=corpo,
                     headers={"Authorization": f"Bearer {token_usuario(operador, 'OPERADOR')}"})
    assert ok.status_code == 200 and ok.json()["abrir"] is True
    with SessionLocal() as db:
        sessao = db.query(Sessao).filter_by(agendamento_id=ag).one()
        assert sessao.origem == "OPERADOR" and "celular sem bateria" in sessao.motivo


def test_acessos_do_dia_e_limpeza_de_notas(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    r = client.post("/api/catraca/entrada", json={"qr": token_qr(ag, usuario), "foto": FOTO}, headers=dispositivo())
    nota_id = r.json()["notaId"]
    operador = {"Authorization": f"Bearer {token_usuario(uuid.uuid4(), 'OPERADOR')}"}
    dia = agora().date().isoformat()
    lista = client.get(f"/api/acessos?dia={dia}", headers=operador).json()
    assert any(s["agendamentoId"] == str(ag) for s in lista)

    admin = {"Authorization": f"Bearer {token_usuario(uuid.uuid4(), 'ADMIN')}"}
    futuro = (agora() + timedelta(days=1)).isoformat()
    limpeza = client.post("/api/admin/notas/limpeza", params={"ate": futuro}, headers=admin)
    assert limpeza.status_code == 200 and limpeza.json()["removidas"] >= 1
    sumiu = client.get(f"/api/notas/{nota_id}/foto", headers={"Authorization": f"Bearer {token_usuario(usuario)}"})
    assert sumiu.status_code == 404


def test_outbox_registra_os_eventos_de_acesso(client):
    usuario, ag = uuid.uuid4(), uuid.uuid4()
    confirmar(ag, usuario)
    qr = token_qr(ag, usuario)
    client.post("/api/catraca/entrada", json={"qr": qr}, headers=dispositivo())
    client.post("/api/catraca/saida", json={"qr": qr}, headers=dispositivo())
    with SessionLocal() as db:
        rks = sorted(o.routing_key for o in db.query(OutboxEvento).all())
    assert rks == ["acesso.entrada-registrada", "acesso.saida-registrada"]


def test_notas_do_usuario_nao_mostram_notas_de_outro(client):
    dono, outro, ag = uuid.uuid4(), uuid.uuid4(), uuid.uuid4()
    confirmar(ag, dono)
    client.post("/api/catraca/entrada", json={"qr": token_qr(ag, dono)}, headers=dispositivo())
    minhas = client.get("/api/notas", headers={"Authorization": f"Bearer {token_usuario(outro)}"}).json()
    assert minhas == []
