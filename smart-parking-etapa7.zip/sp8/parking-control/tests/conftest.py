import os

# Valores locais para os testes. No Docker, o compose fornece os reais.
os.environ.setdefault("DATABASE_URL", "postgresql+psycopg://control:teste-control@localhost:5432/control")
os.environ.setdefault("AWS_ENDPOINT_URL", "http://localhost:4566")
os.environ.setdefault("AWS_DEFAULT_REGION", "sa-east-1")
os.environ.setdefault("AWS_ACCESS_KEY_ID", "test")
os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "test")
os.environ.setdefault("MENSAGERIA_HABILITADA", "false")
