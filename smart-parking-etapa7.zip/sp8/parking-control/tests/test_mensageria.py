import asyncio
import json

from app import mensageria, servicos

EVENTO = {"messageId": "6f1c2a9e-0b3d-4f7a-9c1e-2d8b7a6e5f10", "type": "AgendamentoExpirado",
          "payload": {"agendamentoId": "a3b9c1d2-7e4f-4a6b-8c9d-0e1f2a3b4c5d"}}


class Mensagem:
    def __init__(self, corpo: bytes):
        self.body = corpo
        self.acks = 0
        self.rejeicoes = []

    async def ack(self):
        self.acks += 1

    async def reject(self, requeue=False):
        self.rejeicoes.append(requeue)


def sem_espera(monkeypatch):
    async def dormir(_):
        return None
    monkeypatch.setattr(mensageria.asyncio, "sleep", dormir)


def test_erro_transitorio_repete_ate_dar_certo_sem_ir_para_dlq(monkeypatch):
    sem_espera(monkeypatch)
    chamadas = {"n": 0}

    def processar(evento):
        chamadas["n"] += 1
        if chamadas["n"] < 3:
            raise RuntimeError("banco fora do ar")

    monkeypatch.setattr(servicos, "processar_evento_agendamento", processar)
    msg = Mensagem(json.dumps(EVENTO).encode())
    asyncio.run(mensageria._tratar(msg))
    assert chamadas["n"] == 3
    assert msg.acks == 1
    assert msg.rejeicoes == []


def test_json_invalido_e_devolvido_para_contar_tentativas(monkeypatch):
    sem_espera(monkeypatch)
    msg = Mensagem(b"isto nao e json")
    asyncio.run(mensageria._tratar(msg))
    assert msg.acks == 0
    assert msg.rejeicoes == [True]


def test_campo_faltando_e_erro_permanente(monkeypatch):
    sem_espera(monkeypatch)

    def processar(evento):
        raise KeyError("agendamentoId")

    monkeypatch.setattr(servicos, "processar_evento_agendamento", processar)
    msg = Mensagem(json.dumps(EVENTO).encode())
    asyncio.run(mensageria._tratar(msg))
    assert msg.acks == 0
    assert msg.rejeicoes == [True]
