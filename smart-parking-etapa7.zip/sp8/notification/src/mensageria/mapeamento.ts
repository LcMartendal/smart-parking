/** Envelope padrão (contracts/envelope.schema.json). */
export interface Envelope {
  messageId: string;
  correlationId: string;
  type: string;
  version: number;
  occurredAt: string;
  payload: Record<string, unknown>;
}

export interface Aviso {
  usuarioId: string;
  tipo: string;
  mensagem: string;
}

/** Erro de payload: não se corrige com nova tentativa. A mensagem vai para a DLQ depois do limite (F4). */
export class PayloadInvalidoError extends Error {}

function texto(p: Record<string, unknown>, campo: string): string {
  const valor = p[campo];
  if (typeof valor !== 'string' || valor.length === 0) {
    throw new PayloadInvalidoError(`campo obrigatório ausente: ${campo}`);
  }
  return valor;
}

/** Converte um evento em aviso ao usuário. Eventos sem aviso retornam null. */
export function montarAviso(env: Envelope): Aviso | null {
  const p = env.payload;
  switch (env.type) {
    case 'AgendamentoCriado':
      return { usuarioId: texto(p, 'usuarioId'), tipo: env.type,
        mensagem: 'Reserva criada. Aguardando o pagamento para confirmar.' };
    case 'AgendamentoConfirmado':
      return { usuarioId: texto(p, 'usuarioId'), tipo: env.type,
        mensagem: `Agendamento confirmado para ${texto(p, 'inicio')}. Seu QR code já está disponível.` };
    case 'AgendamentoCancelado': {
      const pct = Number(p['percentualReembolso']);
      if (Number.isNaN(pct)) throw new PayloadInvalidoError('percentualReembolso inválido');
      return { usuarioId: texto(p, 'usuarioId'), tipo: env.type,
        mensagem: `Agendamento cancelado. Reembolso de ${Math.round(pct * 100)}%.` };
    }
    case 'AgendamentoExpirado':
      return { usuarioId: texto(p, 'usuarioId'), tipo: env.type,
        mensagem: 'Agendamento expirado por falta de pagamento no prazo.' };
    case 'EntradaRegistrada': {
      const origem = p['origem'] === 'OPERADOR' ? ' (abertura manual pelo operador)' : '';
      return { usuarioId: texto(p, 'usuarioId'), tipo: env.type,
        mensagem: `Entrada registrada${origem}.` };
    }
    case 'SaidaRegistrada':
      return { usuarioId: texto(p, 'usuarioId'), tipo: env.type, mensagem: 'Saída registrada.' };
    default:
      return null;
  }
}

/** Valida o envelope antes de qualquer efeito. Campo ausente é erro de payload. */
export function lerEnvelope(corpo: string): Envelope {
  let dados: unknown;
  try {
    dados = JSON.parse(corpo);
  } catch {
    throw new PayloadInvalidoError('payload não é JSON válido');
  }
  const e = dados as Partial<Envelope>;
  if (!e || typeof e.messageId !== 'string' || typeof e.type !== 'string' || typeof e.payload !== 'object' || e.payload === null) {
    throw new PayloadInvalidoError('envelope incompleto');
  }
  return e as Envelope;
}
