import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import * as amqp from 'amqplib';
import { config } from '../config';
import { NotificacoesService } from '../notificacoes/notificacoes.service';
import { PayloadInvalidoError, lerEnvelope } from './mapeamento';

const FILAS = ['notification.agendamentos', 'notification.acessos'];

const pausa = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * Consumo com reconexão (R6). Erro transitório (banco, conexão) é repetido dentro do consumidor, com espera
 * crescente. Erro de payload é devolvido ao broker e vai para a DLQ após 3 tentativas (RN-16, F4).
 */
@Injectable()
export class ConsumidorService implements OnModuleInit, OnModuleDestroy {
  private readonly log = new Logger(ConsumidorService.name);
  private ativo = true;
  private conexao?: amqp.ChannelModel;

  constructor(private readonly notificacoes: NotificacoesService) {}

  onModuleInit(): void {
    for (const fila of FILAS) {
      void this.laco(fila);
    }
  }

  async onModuleDestroy(): Promise<void> {
    this.ativo = false;
    await this.conexao?.close().catch(() => undefined);
  }

  private async laco(fila: string): Promise<void> {
    while (this.ativo) {
      try {
        this.conexao = await amqp.connect(config.rabbitmqUrl);
        this.conexao.on('error', (e: Error) => this.log.warn(`conexão com o broker: ${e.message}`));
        const canal = await this.conexao.createChannel();
        await canal.prefetch(10);
        await canal.consume(fila, (msg) => {
          if (!msg) return;
          void this.tratar(canal, msg);
        });
        this.log.log(`consumindo ${fila}`);
        await new Promise<void>((resolve) => this.conexao?.once('close', () => resolve()));
      } catch (e) {
        this.log.warn(`broker indisponível para ${fila}; nova tentativa em 2 s: ${(e as Error).message}`);
      }
      if (this.ativo) await pausa(2000);
    }
  }

  private async tratar(canal: amqp.Channel, msg: amqp.ConsumeMessage): Promise<void> {
    let env;
    try {
      env = lerEnvelope(msg.content.toString('utf8'));
    } catch (e) {
      this.log.error(`payload inválido (${(e as Error).message}); reenvio até a DLQ`);
      canal.nack(msg, false, true);
      return;
    }
    let espera = 500;
    while (this.ativo) {
      try {
        await this.notificacoes.processar(env);
        canal.ack(msg);
        return;
      } catch (e) {
        if (e instanceof PayloadInvalidoError) {
          this.log.error(`evento inválido (${e.message}); reenvio até a DLQ`);
          canal.nack(msg, false, true);
          return;
        }
        if (String((e as { code?: string }).code) === '23505') {
          // Duplicata que chegou em paralelo: o efeito já foi gravado pela outra entrega.
          canal.ack(msg);
          return;
        }
        this.log.warn(`erro transitório; nova tentativa em ${espera} ms: ${(e as Error).message}`);
        await pausa(espera);
        espera = Math.min(30000, espera * 2);
      }
    }
  }
}
