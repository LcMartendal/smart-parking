import { CanActivate, ExecutionContext, Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';

/** Valida o JWT emitido pelo Parking (HS256). O usuário fica em req.usuario. */
@Injectable()
export class JwtGuard implements CanActivate {
  constructor(@Inject('JWT_KEY') private readonly chave: string) {}

  canActivate(ctx: ExecutionContext): boolean {
    const req = ctx.switchToHttp().getRequest();
    const cabecalho: string | undefined = req.headers['authorization'];
    if (!cabecalho || !cabecalho.startsWith('Bearer ')) {
      throw new UnauthorizedException();
    }
    try {
      const payload = jwt.verify(cabecalho.slice(7), this.chave, { algorithms: ['HS256'] }) as jwt.JwtPayload;
      if (typeof payload.sub !== 'string') throw new UnauthorizedException();
      req.usuario = { id: payload.sub, role: payload['role'] };
      return true;
    } catch {
      throw new UnauthorizedException();
    }
  }
}
