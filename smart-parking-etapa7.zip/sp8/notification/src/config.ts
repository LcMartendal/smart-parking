export const config = {
  databaseUrl: process.env.DATABASE_URL ?? 'postgres://notification:senha@notification-db:5432/notification',
  rabbitmqUrl: process.env.RABBITMQ_URL ?? 'amqp://estacionamento:senha@rabbitmq:5672',
  awsEndpointUrl: process.env.AWS_ENDPOINT_URL || undefined,
  awsRegion: process.env.AWS_DEFAULT_REGION ?? 'sa-east-1',
  secretJwtKey: process.env.SECRET_JWT_KEY ?? 'estacionamento/jwt-key',
  porta: Number(process.env.PORT ?? 8000),
};
