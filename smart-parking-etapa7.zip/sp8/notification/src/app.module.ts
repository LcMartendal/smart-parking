import { Module } from '@nestjs/common';
import { criarDataSource } from './banco/data-source';
import { carregarChaveJwt } from './segredos';
import { JwtGuard } from './auth/jwt.guard';
import { NotificacoesController } from './notificacoes/notificacoes.controller';
import { NotificacoesService } from './notificacoes/notificacoes.service';
import { ConsumidorService } from './mensageria/consumidor.service';

@Module({
  controllers: [NotificacoesController],
  providers: [
    {
      provide: 'DATA_SOURCE',
      useFactory: async () => {
        const ds = criarDataSource();
        await ds.initialize();
        await ds.runMigrations();
        return ds;
      },
    },
    { provide: 'JWT_KEY', useFactory: carregarChaveJwt },
    JwtGuard,
    NotificacoesService,
    ConsumidorService,
  ],
})
export class AppModule {}
