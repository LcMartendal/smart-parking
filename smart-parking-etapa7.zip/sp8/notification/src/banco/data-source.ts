import * as path from 'path';
import { DataSource } from 'typeorm';
import { config } from '../config';
import { Notificacao } from './entidades/notificacao.entity';
import { MensagemProcessada } from './entidades/mensagem-processada.entity';

export function criarDataSource(): DataSource {
  return new DataSource({
    type: 'postgres',
    url: config.databaseUrl,
    entities: [Notificacao, MensagemProcessada],
    migrations: [path.join(__dirname, 'migrations', '*.js')],
    synchronize: false,
  });
}
