import { MigrationInterface, QueryRunner } from 'typeorm';

export class Init1700000000000 implements MigrationInterface {
  name = 'Init1700000000000';

  public async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE notificacao (
      id uuid PRIMARY KEY,
      usuario_id uuid NOT NULL,
      tipo varchar(64) NOT NULL,
      mensagem text NOT NULL,
      message_id uuid NOT NULL UNIQUE,
      criada_em timestamptz NOT NULL
    )`);
    await q.query('CREATE INDEX ix_notificacao_usuario ON notificacao(usuario_id, criada_em)');
    await q.query(`CREATE TABLE mensagem_processada (
      message_id uuid PRIMARY KEY,
      processado_em timestamptz NOT NULL
    )`);
  }

  public async down(q: QueryRunner): Promise<void> {
    await q.query('DROP TABLE mensagem_processada');
    await q.query('DROP TABLE notificacao');
  }
}
