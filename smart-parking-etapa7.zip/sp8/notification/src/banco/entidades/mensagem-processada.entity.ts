import { Column, Entity, PrimaryColumn } from 'typeorm';

/** Idempotência (R1): gravada na mesma transação do efeito. */
@Entity({ name: 'mensagem_processada' })
export class MensagemProcessada {
  @PrimaryColumn('uuid', { name: 'message_id' })
  messageId!: string;

  @Column('timestamptz', { name: 'processado_em' })
  processadoEm!: Date;
}
