import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ name: 'notificacao' })
export class Notificacao {
  @PrimaryColumn('uuid')
  id!: string;

  @Column('uuid', { name: 'usuario_id' })
  usuarioId!: string;

  @Column('varchar', { length: 64 })
  tipo!: string;

  @Column('text')
  mensagem!: string;

  @Column('uuid', { name: 'message_id', unique: true })
  messageId!: string;

  @Column('timestamptz', { name: 'criada_em' })
  criadaEm!: Date;
}
