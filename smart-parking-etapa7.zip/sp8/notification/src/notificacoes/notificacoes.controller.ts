import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { JwtGuard } from '../auth/jwt.guard';
import { NotificacoesService } from './notificacoes.service';

@Controller()
export class NotificacoesController {
  constructor(private readonly svc: NotificacoesService) {}

  /** Responde mesmo sem broker: o serviço continua de pé e reconecta sozinho (R6). */
  @Get('health')
  health() {
    return { status: 'ok' };
  }

  @Get('api/notificacoes')
  @UseGuards(JwtGuard)
  listar(@Req() req: { usuario: { id: string } }) {
    return this.svc.listar(req.usuario.id);
  }
}
