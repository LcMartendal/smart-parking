import { Inject, Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { DataSource } from 'typeorm';
import { Notificacao } from '../banco/entidades/notificacao.entity';
import { MensagemProcessada } from '../banco/entidades/mensagem-processada.entity';
import { Aviso, Envelope, montarAviso } from '../mensageria/mapeamento';

@Injectable()
export class NotificacoesService {
  private readonly log = new Logger(NotificacoesService.name);

  constructor(@Inject('DATA_SOURCE') private readonly ds: DataSource) {}

  /**
   * Processa uma mensagem de forma idempotente (R1): o messageId e o aviso são gravados
   * na mesma transação. Retorna false se a mensagem já tinha sido processada.
   */
  async processar(env: Envelope): Promise<boolean> {
    const aviso = montarAviso(env);
    return this.ds.transaction(async (em) => {
      const ja = await em.findOne(MensagemProcessada, { where: { messageId: env.messageId } });
      if (ja) return false;
      await em.insert(MensagemProcessada, { messageId: env.messageId, processadoEm: new Date() });
      if (aviso) {
        await this.gravarAviso(em, env.messageId, aviso);
        this.log.log(`aviso ${aviso.tipo} para ${aviso.usuarioId}`);
      }
      return true;
    });
  }

  private async gravarAviso(em: import('typeorm').EntityManager, messageId: string, aviso: Aviso): Promise<void> {
    await em.insert(Notificacao, {
      id: randomUUID(),
      usuarioId: aviso.usuarioId,
      tipo: aviso.tipo,
      mensagem: aviso.mensagem,
      messageId,
      criadaEm: new Date(),
    });
  }

  listar(usuarioId: string): Promise<Notificacao[]> {
    return this.ds.getRepository(Notificacao).find({
      where: { usuarioId },
      order: { criadaEm: 'DESC' },
      take: 100,
    });
  }
}
