import { GetSecretValueCommand, SecretsManagerClient } from '@aws-sdk/client-secrets-manager';
import { config } from './config';

/** Lê a chave de JWT do Secrets Manager. Sem ela o serviço não sobe. */
export async function carregarChaveJwt(): Promise<string> {
  const sm = new SecretsManagerClient({ region: config.awsRegion, endpoint: config.awsEndpointUrl });
  const resposta = await sm.send(new GetSecretValueCommand({ SecretId: config.secretJwtKey }));
  if (!resposta.SecretString) {
    throw new Error(`segredo ${config.secretJwtKey} vazio`);
  }
  return resposta.SecretString;
}
