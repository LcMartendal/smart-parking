import { test } from 'node:test';
import * as assert from 'node:assert/strict';
import { PayloadInvalidoError, lerEnvelope, montarAviso } from '../mensageria/mapeamento';

const base = { messageId: '6f1c2a9e-0b3d-4f7a-9c1e-2d8b7a6e5f10', correlationId: 'a3b9c1d2-7e4f-4a6b-8c9d-0e1f2a3b4c5d', version: 1, occurredAt: '2026-11-25T10:00:00Z' };
const usuario = '11111111-1111-4111-8111-111111111111';

test('cancelamento com 50% gera aviso com o percentual', () => {
  const a = montarAviso({ ...base, type: 'AgendamentoCancelado', payload: { usuarioId: usuario, percentualReembolso: 0.5 } });
  assert.equal(a?.mensagem, 'Agendamento cancelado. Reembolso de 50%.');
});

test('entrada feita pelo operador aparece no aviso', () => {
  const a = montarAviso({ ...base, type: 'EntradaRegistrada', payload: { usuarioId: usuario, origem: 'OPERADOR' } });
  assert.match(a!.mensagem, /operador/);
});

test('evento sem aviso ao usuário retorna null', () => {
  assert.equal(montarAviso({ ...base, type: 'EventoDesconhecido', payload: {} }), null);
});

test('campo obrigatório ausente é erro de payload', () => {
  assert.throws(() => montarAviso({ ...base, type: 'AgendamentoConfirmado', payload: {} }), PayloadInvalidoError);
});

test('corpo que não é JSON é erro de payload', () => {
  assert.throws(() => lerEnvelope('isto não é json'), PayloadInvalidoError);
});

test('envelope sem messageId é erro de payload', () => {
  assert.throws(() => lerEnvelope(JSON.stringify({ type: 'SaidaRegistrada', payload: {} })), PayloadInvalidoError);
});
