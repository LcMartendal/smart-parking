import { after, before, test } from 'node:test';
import * as assert from 'node:assert/strict';
import { randomUUID } from 'crypto';
import { DataSource } from 'typeorm';
import { criarDataSource } from '../banco/data-source';
import { Notificacao } from '../banco/entidades/notificacao.entity';
import { NotificacoesService } from '../notificacoes/notificacoes.service';

let ds: DataSource;
let svc: NotificacoesService;
const usuario = randomUUID();

before(async () => {
  ds = criarDataSource();
  await ds.initialize();
  await ds.runMigrations();
  svc = new NotificacoesService(ds);
});

after(async () => {
  await ds.query('DELETE FROM notificacao WHERE usuario_id = $1', [usuario]);
  await ds.destroy();
});

const evento = (messageId: string) => ({
  messageId, correlationId: randomUUID(), type: 'AgendamentoExpirado', version: 1,
  occurredAt: new Date().toISOString(), payload: { usuarioId: usuario, agendamentoId: randomUUID() },
});

test('a mesma mensagem repetida gera um único aviso (F3)', async () => {
  const id = randomUUID();
  const primeira = await svc.processar(evento(id));
  const segunda = await svc.processar(evento(id));
  const cinco = await Promise.all([1, 2, 3].map(() => svc.processar(evento(id))));
  assert.equal(primeira, true);
  assert.equal(segunda, false);
  assert.equal(cinco.every((x) => x === false), true);
  const total = await ds.getRepository(Notificacao).count({ where: { messageId: id } });
  assert.equal(total, 1);
});

test('mensagens diferentes geram avisos diferentes', async () => {
  await svc.processar(evento(randomUUID()));
  await svc.processar(evento(randomUUID()));
  const total = await ds.getRepository(Notificacao).count({ where: { usuarioId: usuario } });
  assert.ok(total >= 2);
});
