# Contratos de mensagens

Todas as mensagens usam o envelope `envelope.schema.json`: `messageId`, `correlationId`, `type`, `version`, `occurredAt` e `payload`.

Exchange principal: `estacionamento` (topic). Dead-letter: `estacionamento.dlx`.

| Tipo (v1) | Routing key | Schema |
|---|---|---|
| CobrancaSolicitada | `pagamento.cobranca-solicitada` | `eventos/CobrancaSolicitada.v1.schema.json` |
| EstornoSolicitado | `pagamento.estorno-solicitado` | `eventos/EstornoSolicitado.v1.schema.json` |
| PagamentoAprovado | `pagamento.aprovado` | `eventos/PagamentoAprovado.v1.schema.json` |
| PagamentoRecusado | `pagamento.recusado` | `eventos/PagamentoRecusado.v1.schema.json` |
| PagamentoEstornado | `pagamento.estornado` | `eventos/PagamentoEstornado.v1.schema.json` |
| AgendamentoConfirmado | `agendamento.confirmado` | `eventos/AgendamentoConfirmado.v1.schema.json` |
| AgendamentoCancelado | `agendamento.cancelado` | `eventos/AgendamentoCancelado.v1.schema.json` |
| AgendamentoExpirado | `agendamento.expirado` | `eventos/AgendamentoExpirado.v1.schema.json` |
| EntradaRegistrada | `acesso.entrada-registrada` | `eventos/EntradaRegistrada.v1.schema.json` |
| SaidaRegistrada | `acesso.saida-registrada` | `eventos/SaidaRegistrada.v1.schema.json` |
