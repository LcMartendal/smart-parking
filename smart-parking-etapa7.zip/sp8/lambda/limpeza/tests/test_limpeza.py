import importlib.util
import io
import os
import pathlib
import uuid

import boto3
import pytest
from botocore.config import Config

ENDPOINT = os.getenv("AWS_ENDPOINT_URL", "http://localhost:4566")
BUCKET = f"teste-limpeza-{uuid.uuid4().hex[:8]}"
os.environ["AWS_ENDPOINT_URL"] = ENDPOINT
os.environ["AWS_DEFAULT_REGION"] = "sa-east-1"
os.environ["AWS_ACCESS_KEY_ID"] = "test"
os.environ["AWS_SECRET_ACCESS_KEY"] = "test"
os.environ["BUCKET_COMPROVANTES"] = BUCKET

spec = importlib.util.spec_from_file_location("handler", pathlib.Path(__file__).parents[1] / "handler.py")
handler = importlib.util.module_from_spec(spec)
spec.loader.exec_module(handler)


@pytest.fixture
def s3():
    cliente = boto3.client("s3", endpoint_url=ENDPOINT, region_name="sa-east-1",
                           aws_access_key_id="test", aws_secret_access_key="test",
                           config=Config(s3={"addressing_style": "path"}))
    cliente.create_bucket(Bucket=BUCKET, CreateBucketConfiguration={"LocationConstraint": "sa-east-1"})
    for i in range(3):
        cliente.put_object(Bucket=BUCKET, Key=f"fotos/{i}.jpg", Body=io.BytesIO(b"x"))
    cliente.put_object(Bucket=BUCKET, Key="outros/nao-mexer.txt", Body=io.BytesIO(b"x"))
    yield cliente
    for obj in cliente.list_objects_v2(Bucket=BUCKET).get("Contents", []):
        cliente.delete_object(Bucket=BUCKET, Key=obj["Key"])
    cliente.delete_bucket(Bucket=BUCKET)


def test_foto_recente_e_mantida_com_retencao_de_90_dias(s3):
    resultado = handler.lambda_handler({"retencao_dias": 90}, None)
    assert resultado["examinadas"] == 3
    assert resultado["removidas"] == 0
    assert len(s3.list_objects_v2(Bucket=BUCKET, Prefix="fotos/")["Contents"]) == 3


def test_retencao_negativa_remove_todas_as_fotos_e_so_elas(s3):
    resultado = handler.lambda_handler({"retencao_dias": -1}, None)
    assert resultado["removidas"] == 3
    assert "Contents" not in s3.list_objects_v2(Bucket=BUCKET, Prefix="fotos/")
    assert len(s3.list_objects_v2(Bucket=BUCKET, Prefix="outros/")["Contents"]) == 1


def test_evento_vazio_usa_a_variavel_de_ambiente(s3, monkeypatch):
    monkeypatch.setenv("RETENCAO_FOTOS_DIAS", "90")
    resultado = handler.lambda_handler(None, None)
    assert resultado["removidas"] == 0
