"""Limpeza de fotos antigas no S3 (RF-18). Disparada pelo EventBridge uma vez por dia.

Só mexe no S3. A limpeza das linhas dos bancos fica com os próprios serviços (decisão D-19).
O evento pode trazer "retencao_dias" para testes; sem ele, vale RETENCAO_FOTOS_DIAS.
"""
import json
import logging
import os
from datetime import UTC, datetime, timedelta

import boto3
from botocore.config import Config

log = logging.getLogger()
log.setLevel(logging.INFO)


def _cliente_s3():
    return boto3.client(
        "s3",
        endpoint_url=os.getenv("AWS_ENDPOINT_URL") or None,
        region_name=os.getenv("AWS_DEFAULT_REGION", "sa-east-1"),
        config=Config(s3={"addressing_style": "path"}),
    )


def lambda_handler(event, context):
    evento = event or {}
    dias = int(evento.get("retencao_dias", os.getenv("RETENCAO_FOTOS_DIAS", "90")))
    bucket = os.getenv("BUCKET_COMPROVANTES", "estacionamento-comprovantes")
    corte = datetime.now(UTC) - timedelta(days=dias)

    s3 = _cliente_s3()
    examinadas = 0
    removidas = 0
    for pagina in s3.get_paginator("list_objects_v2").paginate(Bucket=bucket, Prefix="fotos/"):
        for objeto in pagina.get("Contents", []):
            examinadas += 1
            if objeto["LastModified"] < corte:
                s3.delete_object(Bucket=bucket, Key=objeto["Key"])
                removidas += 1

    resultado = {"bucket": bucket, "corte": corte.isoformat(), "examinadas": examinadas, "removidas": removidas}
    log.info(json.dumps(resultado))
    return resultado
