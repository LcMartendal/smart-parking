output "bucket_comprovantes" {
  description = "Bucket das fotos e notas."
  value       = aws_s3_bucket.comprovantes.bucket
}

output "segredos_criados" {
  description = "Nomes dos segredos (os valores não são exibidos)."
  value       = nonsensitive(keys(local.segredos))
}
