resource "random_password" "jwt_key" {
  length  = 64
  special = false
}

resource "random_password" "qr_key" {
  length  = 64
  special = false
}

resource "random_password" "device_key" {
  length  = 48
  special = false
}

locals {
  # nome do segredo => valor
  segredos = {
    "estacionamento/jwt-key"         = random_password.jwt_key.result
    "estacionamento/qr-key"          = random_password.qr_key.result
    "estacionamento/device-key"      = random_password.device_key.result
    "estacionamento/parking-db"      = var.parking_db_password
    "estacionamento/control-db"      = var.control_db_password
    "estacionamento/notification-db" = var.notification_db_password
  }
}

resource "aws_secretsmanager_secret" "segredo" {
  for_each                = local.segredos
  name                    = each.key
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret_version" "segredo" {
  for_each      = local.segredos
  secret_id     = aws_secretsmanager_secret.segredo[each.key].id
  secret_string = each.value
}
