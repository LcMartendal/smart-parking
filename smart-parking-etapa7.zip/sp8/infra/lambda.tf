# Limpeza de fotos antigas (RF-18). A Lambda só mexe no S3 (D-19).
data "archive_file" "limpeza" {
  type        = "zip"
  source_file = "${path.module}/../lambda/limpeza/handler.py"
  output_path = "${path.module}/build/limpeza.zip"
}

resource "aws_iam_role" "limpeza" {
  name = "estacionamento-limpeza-fotos"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "limpeza_s3" {
  name = "fotos-s3"
  role = aws_iam_role.limpeza.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["s3:ListBucket", "s3:DeleteObject"]
      Resource = [aws_s3_bucket.comprovantes.arn, "${aws_s3_bucket.comprovantes.arn}/fotos/*"]
    }]
  })
}

resource "aws_lambda_function" "limpeza" {
  function_name    = "estacionamento-limpeza-fotos"
  role             = aws_iam_role.limpeza.arn
  runtime          = "python3.13"
  handler          = "handler.lambda_handler"
  filename         = data.archive_file.limpeza.output_path
  source_code_hash = data.archive_file.limpeza.output_base64sha256
  timeout          = 60

  environment {
    variables = {
      BUCKET_COMPROVANTES = var.bucket_name
      RETENCAO_FOTOS_DIAS = tostring(var.retencao_fotos_dias)
      AWS_ENDPOINT_URL    = var.endpoint
    }
  }
}
