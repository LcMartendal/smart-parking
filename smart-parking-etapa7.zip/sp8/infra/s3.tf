# Fotos e notas. Não há expiração automática: a limpeza é feita pelo administrador,
# pelo endpoint de limpeza de notas do Parking Control.
resource "aws_s3_bucket" "comprovantes" {
  bucket        = var.bucket_name
  force_destroy = true

  tags = {
    Projeto = "estacionamento"
  }
}
