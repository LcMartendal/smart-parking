# Disparo diário da limpeza: 06:00 UTC, que são 03:00 em Brasília (RF-18).
resource "aws_cloudwatch_event_rule" "limpeza_diaria" {
  name                = "estacionamento-limpeza-diaria"
  description         = "Dispara a limpeza de fotos antigas todos os dias"
  schedule_expression = "cron(0 6 * * ? *)"
}

resource "aws_cloudwatch_event_target" "limpeza" {
  rule      = aws_cloudwatch_event_rule.limpeza_diaria.name
  target_id = "limpeza-fotos"
  arn       = aws_lambda_function.limpeza.arn
}

resource "aws_lambda_permission" "eventbridge" {
  statement_id  = "permitir-eventbridge"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.limpeza.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.limpeza_diaria.arn
}
