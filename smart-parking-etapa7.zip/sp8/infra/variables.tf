variable "endpoint" {
  description = "Endpoint do MiniStack."
  type        = string
  default     = "http://localhost:4566"
}

variable "region" {
  description = "Região simulada (São Paulo)."
  type        = string
  default     = "sa-east-1"
}

variable "access_key" {
  description = "Credencial de teste do MiniStack."
  type        = string
  default     = "test"
}

variable "secret_key" {
  description = "Credencial de teste do MiniStack."
  type        = string
  default     = "test"
  sensitive   = true
}

variable "bucket_name" {
  description = "Bucket das fotos e notas."
  type        = string
  default     = "estacionamento-comprovantes"
}

variable "parking_db_password" {
  description = "Senha do banco do Parking. Mesmo valor usado no contêiner do Postgres."
  type        = string
  sensitive   = true
}

variable "control_db_password" {
  description = "Senha do banco do Parking Control."
  type        = string
  sensitive   = true
}


variable "notification_db_password" {
  description = "Senha do banco do Notification."
  type        = string
  sensitive   = true
}

variable "retencao_fotos_dias" {
  description = "Fotos com mais de N dias são apagadas pela Lambda (RN-18)."
  type        = number
  default     = 90
}
