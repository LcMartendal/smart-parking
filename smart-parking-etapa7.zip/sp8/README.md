# Estacionamento com agendamento e acesso por QR code

Projeto da disciplina de Sistemas Distribuídos (FURB, prof. Gabriel Castellani de Oliveira).

**Grupo:** Luiz C. Martendal, Fabian Formento, Guilherme B. Hansen, Lucas Visconti e Venâncio D. Cassua.

O sistema agenda vagas pelo navegador do celular, cobra antecipadamente, libera a entrada por QR code na catraca e avisa o usuário em cada etapa. Os serviços se comunicam por mensageria assíncrona com RabbitMQ.

## Status

| Etapa | Situação |
|---|---|
| Dia 1: contratos, RabbitMQ, Terraform e compose base | Concluída |
| Parking (Java 25): login e roles, agendamento, saga, cancelamento, expiração e QR | Implementada (sem execução ainda) |
| Cobrança interna no Parking (banco simulado, estorno e worker) | Implementada (sem execução ainda) |
| Parking Control (Python): catraca, QR, sessões, foto e nota | Pendente |
| Notification (TypeScript): avisos e notificações do usuário | Pendente |
| Interface web | Pendente |
| Cenários de falha F1 a F8 | Pendente |

## Arquitetura

| Serviço | Tecnologia | Banco |
|---|---|---|
| Parking | Java 25, Spring Boot 4.1 | parking-db |
| Parking Control | Java 25, Spring Boot 4.1 | control-db |
| Notification | TypeScript, NestJS 12, Node 26 | notification-db |
| Gateway e interface | nginx | — |
| Mensageria | RabbitMQ 4 | — |
| Nuvem simulada | MiniStack (S3 e Secrets Manager), região sa-east-1 | — |
| Infraestrutura | Terraform | — |

O plano completo, com fluxos, regras de negócio e cenários de falha, está em [`docs/plano_de_execucao.md`](docs/plano_de_execucao.md). Os contratos das mensagens ficam em [`contracts/`](contracts/README.md).

## Como subir

```bash
cp .env.example .env          # troque todas as senhas
docker compose up -d --build
./scripts/infra/verificar.sh
```

Fluxo para testar pelo gateway (porta 8080):

```bash
# 1. cadastro e login
curl -X POST localhost:8080/api/auth/cadastro -H "Content-Type: application/json" \
  -d '{"email":"ana@teste.com","senha":"senha123"}'
TOKEN=$(curl -s -X POST localhost:8080/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"ana@teste.com","senha":"senha123"}' | python3 -c "import sys,json;print(json.load(sys.stdin)['token'])")

# 2. agendar (202 Accepted; o status vira CONFIRMADO depois do pagamento)
curl -i -X POST localhost:8080/api/agendamentos -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" -d '{"inicio":"2026-11-25T14:00:00Z"}'

# 3. consultar o status e obter o QR code (quando CONFIRMADO)
curl -s localhost:8080/api/agendamentos -H "Authorization: Bearer $TOKEN"
```

## Como subir (infraestrutura)

Pré-requisitos: Docker com o plugin `docker compose`, e o `aws` CLI (apenas para o script de verificação).

```bash
cp .env.example .env          # troque as senhas antes de continuar
docker compose up -d
docker compose logs infra     # o Terraform cria o bucket e os segredos e encerra
./scripts/infra/verificar.sh  # confere a infraestrutura
```

O Terraform cria o bucket e os segredos no MiniStack. As chaves de JWT, QR e dispositivo são geradas aleatoriamente. As senhas dos bancos vêm do `.env`, e o mesmo valor é usado no contêiner do Postgres.

Para encerrar sem apagar os dados: `docker compose down`. Para apagar tudo, inclusive os volumes: `docker compose down -v`.

## Estrutura

```
├── docker-compose.yml
├── .env.example
├── contracts/          contratos das mensagens (JSON Schema)
├── rabbitmq/           configuração e topologia do broker
├── infra/              Terraform: bucket S3 e segredos
├── scripts/infra/      verificação da infraestrutura
├── scripts/cenarios/   cenários de falha F1 a F8 (a partir do Dia 7)
└── docs/               plano de execução
```

Os serviços de aplicação (parking-control, notification, gateway e web) entram nos próximos blocos, conforme o cronograma do PRD v5.
